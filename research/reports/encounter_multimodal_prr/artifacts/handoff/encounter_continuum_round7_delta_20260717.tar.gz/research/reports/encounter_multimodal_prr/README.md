# Prescribed finite-window encounter-reaction modality under conserved reactivity

This directory is the independent Physical Review Research project that follows
`encounter_heterogeneous_catalytic`.  It is not a revision folder for that
finite-model paper.  The new paper is gated by a continuum result:

> Under a physically defined conserved reactivity budget, construct and control
> stable multimodal reaction-time densities for prescribed finite designs, and
> verify their modality topology in a resolved encounter model.  For every fixed
> finite integer $d\ge2$, an independently audited theorem gives exactly every
> prescribed fixed finite number of nondegenerate maxima, separated by exactly
> one fewer nondegenerate minima, in a
> $d$- and $m$-dependent narrow-noise slab family of the exact physical Doi
> quotient, after taking the joint noise/slab-width and positive-budget limits
> sequentially.  Relative-prominence-qualified four-slab $B=0$ shapes are confirmed
> by exact physical-$d=2$ disk and physical-$d=3$ sphere kernels; a separate broad-
> patch $B=0$ chain bridges the exact $d=2$ kernel to four finite-volume meshes, and
> one finite-$B$ fold is confirmed on a single mesh.  At fixed $B=0.01$, one
> result-informed broad four-slab allocation, tested without refitting, has three
> event-mass-qualified modes on two held-out odd finite-volume meshes in one fixed
> reflecting box and the same solver family: five retained alternating roots are
> supported by the saved root screen only through $t=35$, while the valley-
> partitioned basin masses and tail checks extend through $t=100$.  This does not
> exclude additional extrema after $t=35$.  The later allocation-v6 cusp campaign
> terminated with `HOLD_SCIENCE_AUDIT_VALID`; it is preserved as a negative result,
> not an open gate to be repaired.  The active route is theorem-first: use the
> accepted exact-$m$ complete-topology theorem, then test prospectively frozen same-budget
> one-/two-/three-mode controls with a full-window interval certificate, all mesh/
> parity/alignment/box challenges, and an independent off-lattice event law.  The
> complete reader-facing proof and its theorem-first main/Supplemental package
> passed the independent hash-specific Round-149 audit with `P0=P1=P2=0`; this
> closes the analytical migration only and promotes no finite-parameter result.

## Scope boundary

- The earlier report establishes finite-generator response identities, spectral
  necessary conditions, and finite-grid mechanism certificates.
- This report adds a constructive exact-topology theory and a weak-budget
  model-specific continuum bridge; the focused finite-parameter evidence still
  required is physical `d=2`, while positive-budget `d=3` is optional unless a
  dimensional headline is used.
- Extra scans of the old sharp-mask discretization do not count as PRR evidence.
- Reduced GIG mixtures are analytical design and screening objects.  They are
  not evidence for a bounded Doi continuum until a uniform remainder or an
  independently converged continuum realization is supplied.

## Evidence gates

| Gate | Required evidence | Current status |
| --- | --- | --- |
| G0 | Reproducible finite-`m` GIG construction (`m=2,...,6`) and nondegenerate reduced cusp | PASS (reduced numerical scope only) |
| G1a | Exact physical-2D quotient operator geometry, budget, positivity, mass, and independent local references | PASS (42 mutation-hardened gates on 15,625 cells; `continuum_verified=false`) |
| G1b | Frozen full-simplex search and one physical-budget 2D fold with odd/even convergence | full simplex PASS; one $B=0.6$, 207,025-state fold PASS; mesh/box convergence open |
| G2 | Same-budget physical-2D control of finite-window modality | historical $B=0$ and one fixed $B=0.01$ point are context only; allocation-v6 is terminal `HOLD`; Round 167 accepts the 12-row control-free source/partition/free-axis/packed-rate preparation and clean serialized replay, Round 168 freezes the same-core contact/support factor bundle with all 4,142 exact full cells serialized as `[1,1]`, and Round 169 accepts only the separate-source child core/file wire; the two-repeat outer replay, concrete killing, full operator, propagation/topology, production resource gate, F0, and all 36 F1 rows remain open |
| G3 | Independent off-lattice event-law validation without refitting | compiled state-dependent-hazard core and 22 method tests PASS; selector process/resource surface passed Rounds 151/153 on macOS (142/142 suite, 120/120 repair replays, 45 independent orphan probes, 8M synthetic gate); second-POSIX and causal second-parent contention handshakes remain P2, and F2/F3 science is unrun |
| G4 | Constructive physical finite-mode theorem plus weak-budget transfer | analytical core accepted in Rounds 118/120 (`ACCEPT-THEOREM-SPINE`); the integrated reader-facing exact-$m$ proof, theorem-first narrative, and frozen source bytes independently passed Round 149 with `P0=P1=P2=0` |
| G5 | Dimensional scope | exact fixed-finite-$d$ theorem is pointwise in $d$; historical physical-$d=3$ $B=0$ shape is context; the focused active numerical claim is physical $d=2$, with no positive-$B$ $d=3$ headline |
| G6 | One publication narrative with clean overlap/priority boundaries | after the C0-A migration and the audited conditional positive-time bridge, the dedicated fail-closed compiler produced byte-reproducible 7-page main and 24-page Supplement PDFs; all 31 physical pages passed their applicable build/visual gates, while `release_eligible=false` and no positive-budget science is read |

The separate strict-continuum branch remains below C1.  The result-blind C0-v1
contract is immutable historical evidence: its ambiguous “weighted cell
projection” predates the exact-adjoint denominator choice, and its old living-
note source pin now correctly fails closed with `HOLD_C0_CONTRACT_SOURCES`.
The deterministic C0-v2 semantic base uses five C0-only/control-free
JSON sources and does not pin or open the living continuum note, the positive-
budget design note, or any scratch/result payload.  It freezes distinct
`J_h,P_h,A_h,S_h`, the global fixed-box mass gauge, real and optional-complex
form conventions, the row-generator convention, and the exact initial cell
masses; the independent verifier confirms strict support containment in all 12
declared boxes.  A second mathematical attack then found that measurable-
partition and positive-mass well-definedness assumptions were implicit.  The
immutable v2 bytes are therefore retained as a base, and the current C0-v3
wrapper freezes those preconditions explicitly and reconstructs all 36 axis
partitions, including four vertex-dual endpoint-half-volume axes and two
wrapped periodic rows, accounting for all 34,787,462 declared tensor cells.
This remains a local semantic/adversarial candidate only: the exact control
values still require a separately sealed result-blind source, complete C0 is
false, and the raw-to-gauged production bridge remains open.
The current v2/v3 implementation layer passes 86 focused static, currentness,
open-set, and mutation tests.  The latest robustness review closed deep and
over-wide-number JSON exceptions, direct-byte and growing-file size-cap gaps,
bare result/control filename detection, descriptor-relative one-shot
publication, and I/O HOLD normalization without changing either frozen
artifact.
The latest neutral C1 v2 diagnostic covers only the ideal
analytic, fixed-box, one-dimensional, free, cell-centred midpoint OU form.  It
records second-order cell-mass/map/edge ratios, a first-order full-cell density
ratio, exact flat boundary sentinels, and the nonzero detailed-balance residual
of independently selected production binary64 centres.  The repaired Mosco
sublemma remains candidate-labelled, but its final bytes and the repaired v2
diagnostic passed the local hash-specific Round-2 adversarial re-audits with
`P0=P1=P2=0` in their narrow scopes.  This is not external acceptance;
complete C1 remains open.

The current successor layer freezes a separate, result-blind ideal
refinement/rate contract over cell-centred, vertex-dual, periodic-base, and
periodic-half-shift families.  It records the vertex endpoint formula
`q=d/(nu_i*h)B`, the raw tensor product and one global gauge, and the fact that
the 12 existing rows are finite anchors rather than `h -> 0` sequences.  Its
builder, standalone verifier, and static/currentness/mutation suite pass
79/79 tests; after three audit/repair passes its exact final bytes have
`P0=P1=P2=0` in the contract scope.  A separate neutral free-axis/tensor
fixture passes 21/21 tests:
it sees first-order vertex endpoint `rho`, second-order edge and smooth-form
errors, exact periodic wrap/mass/conductance identities, and exact separable
tensor factorization without allocating a three-dimensional array.  The
706-line mathematical successor note passed three formula-level reviews and a
final same-byte review with `P0=P1=P2=0`.  Its abstract
resolvent-to-positive-time functional bridge is now Proposition S3.3 in the
24-page Supplemental working source.  The new contract and fixture still keep
complete C1, the production bridge, C2/C3, root transfer, and release false.

The next abstract successor is the 571-line self-contained varying-space
reconstructed-resolvent-to-Mosco theorem.  It unitarizes the near-isometric
maps with `U_h=J_h(P_hJ_h)^{-1/2}`, proves the liminf through an exact
resolvent variational inequality and spectral dual formula, and constructs
recovery with `beta(L_h+beta)^{-1}U_h^*`.  After three independent emphases,
its final exact bytes have `P0=P1=P2=0`; this closes the abstract free-tensor
Mosco and bounded-killing implications only.  Genuine axis refinement
sequences, exact control-specific averages, the production gauge/application
enclosure, C2/C3, and release remain HOLD.

Round 6 now supplies an 883-line implementation design for that production
gauge/application enclosure.  It pins one global mass gauge, a common exact
flux behind forward/reverse rates, the physical quotient measure and
`W^-1` normalization, and the distinction between the discrete killing
diagonal `B*V` and reconstructed multiplier `B*K` with `K=V/rho`.  Two final
exact-byte design audits report `P0=P1=P2=0`, but the symbolic machine
contract, independent acceptance receipt, exact controls, budget application,
and complete C0--C2 all remain false.

Round 7 selects a conditional quantitative route from an `O(h^(1/2))` sharp
cut-layer form defect through complex-sector reconstructed resolvents to
positive-time `r=0,1,2` observables for `tau>0`.  Its 539-line theory note
passed two exact-byte mathematical audits with `P0=P1=P2=0`.  A separate
result-blind unit-torus cut-layer fixture independently reconstructs 20 exact
rows and passes 97/97 static, mutation, and currentness assertions plus two
direct entry points; two final exact-byte fixture audits also report
`P0=P1=P2=0`.  This validates only the neutral geometry diagnostic.  QF1--QF2,
the source-bound complex-sector rate, production member binding, complete C2,
C3, and release remain HOLD.

PRR remains on HOLD.  The current promotion chain is: accepted exact-$m$
complete-topology theory, the accepted Round-167 control-free production
preparation, the Round-168 same-core factor freeze followed by its still-open
separate-source two-child acceptance, then a complete independently accepted
science-free rate-defined uniformization F0 (still open), one no-refit 36-row same-budget
one-/two-/three-mode F1 with full-window interval roots, and a powered
off-lattice F3 event-law confirmation.  The failed allocation cusp is not a
required rescue condition for this route.

The strict-continuum promotion chain is separate:
map-repaired hash-bound C0 contract -> accepted ideal fixed-1D free-OU Mosco
sublemma -> relative/periodic/tensor/vertex extensions -> sharp-contact killing
consistency -> accepted one-axis/refinement premises -> direct free-tensor
resolvent plus the audited abstract resolvent-to-Mosco implication -> bounded
killing Mosco -> apply the proved abstract positive-time functional bridge ->
implement the audited Round-6 symbolic production bridge and independent
acceptance receipt -> complete C1 -> prove QF1--QF2 and the complex-sector
Round-7 estimate -> quantitative C2 -> box C3 -> componentwise root transfer.
The current production intervals contain only the raw ungauged axis
primitives; the Round-6 document is a design, not the missing enclosure.
All resulting interval/roundoff width stays in `E_eval`; no convergence
theorem is claimed for unrelated binary64 interval centres.

## Reproducible entry points

Run these commands from the repository root with the repository-owned Python
environment; the system `python3` on this machine does not provide the frozen
SciPy/pytest stack.

```bash
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_c1_sg_manufactured.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_c1_sg_manufactured.py research/reports/encounter_multimodal_prr/code/test_continuum_c1_sg_manufactured_adversarial.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/build_continuum_c1_ideal_refinement_contract_candidate_v1.py --check
.venv/bin/python research/reports/encounter_multimodal_prr/code/validate_continuum_c1_ideal_refinement_contract_candidate_v1.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_c1_ideal_refinement_contract_candidate_v1.py research/reports/encounter_multimodal_prr/code/test_continuum_c1_ideal_refinement_contract_v1_currentness.py research/reports/encounter_multimodal_prr/code/test_continuum_c1_ideal_refinement_contract_adversarial_v1.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_c1_free_axes_tensor_diagnostic.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_c1_free_axes_tensor_diagnostic.py research/reports/encounter_multimodal_prr/code/test_continuum_c1_free_axes_tensor_diagnostic_mutations.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/build_continuum_c2_cut_layer_neutral_fixture_v1.py --check
.venv/bin/python research/reports/encounter_multimodal_prr/code/validate_continuum_c2_cut_layer_neutral_fixture_v1.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/test_continuum_c2_cut_layer_neutral_fixture_v1.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/test_continuum_c2_cut_layer_neutral_fixture_mutations_v1.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/test_continuum_c2_cut_layer_neutral_fixture_currentness_v1.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/build_continuum_c0_model_contract_candidate_v2.py --check
.venv/bin/python research/reports/encounter_multimodal_prr/code/validate_continuum_c0_model_contract_candidate_v2.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_c0_model_contract_candidate_v2.py research/reports/encounter_multimodal_prr/code/test_continuum_c0_model_contract_v2_currentness.py research/reports/encounter_multimodal_prr/code/test_continuum_c0_model_contract_adversarial_v2.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/build_continuum_c0_model_contract_candidate_v3.py --check
.venv/bin/python research/reports/encounter_multimodal_prr/code/validate_continuum_c0_model_contract_candidate_v3.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_c0_model_contract_candidate_v3.py research/reports/encounter_multimodal_prr/code/test_continuum_c0_model_contract_adversarial_v3.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_c0_model_contract_current_staleness.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/compile_theorem_first_working.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/check_reproducibility_environment.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_compile_theorem_first_working.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_theorem_first_scope_consistency.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/rate_defined_tensor_f0_production_initial_stream.py verify --bundle research/reports/encounter_multimodal_prr/artifacts/data/physical_production_initial_stream_v1
replay_dir=$(mktemp -d research/reports/encounter_multimodal_prr/tmp/clean-replay.XXXXXX)
.venv/bin/python research/reports/encounter_multimodal_prr/code/rate_defined_tensor_f0_production_initial_clean_replay.py --report-root research/reports/encounter_multimodal_prr --receipt "$replay_dir/receipt.json"
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_rate_defined_tensor_f0_production_initial_stream.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/validate_gig_constructive.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_gig_constructive.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_g1_smoke.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_g1_smoke.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_g1_discovery.py --dry-run
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_g1_discovery.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_g1_manual_review.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_g1_manual_review.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_weak_budget_design.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_weak_budget_design.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/plot_weak_budget_design.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_plot_weak_budget_design.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_g1c_simplex.py --dry-run
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_g1c_simplex.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_g1d_fold_confirmation.py --help
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_g1d_fold_confirmation.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_observable_four_patch.py --help
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_observable_four_patch.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_observable_four_patch_d3.py --help
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_observable_four_patch_d3.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/continuum_broad_patch_b0_bridge.py --help
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_continuum_broad_patch_b0_bridge.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/plot_observable_four_patch.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_plot_observable_four_patch.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/plot_d2_d3_four_patch.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_plot_d2_d3_four_patch.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/plot_positive_b_broad_four_slab.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_plot_positive_b_broad_four_slab.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/build_positive_b_manuscript_input.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_build_positive_b_manuscript_input.py
.venv/bin/python research/reports/encounter_multimodal_prr/code/build_manuscript_inputs.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_compile_manuscript.py
.venv/bin/python -m pytest -q research/reports/encounter_multimodal_prr/code/test_living_scope_consistency.py
```

The scripts write only report-owned outputs. Numerical producers use
`artifacts/data/`; the theorem-first compiler uses a closed analytical source
allowlist and transactionally publishes the main PDF, Supplemental PDF, logs,
and manifest after two byte-identical isolated builds of each document.  The
historical `code/compile_manuscript.py` path is retained for archival
reconstruction, not as the active paper entry point.  That legacy compiler
publishes its generated inputs, PDF, logs, and manifest only after its source
and figure pins and both clean builds pass.  The smoke
command is a pre-fold implementation check. The discovery command shown above
is deliberately a 315-state dry-run; the completed 207,025-state formal run
required the explicit frozen-run flag and all preflight gates.  The manual
review is explicitly post-result evidence: it resolves the `theta=0.7`
subzero derivative wiggle but does not retroactively authorize the original
line-empty action or verify a continuum fold.

The positive-$B$ broad-four-slab result is a closed canonical record, not a
normal rerunnable entry point: two complete sequential producer replicas were
byte-identical before canonical promotion, and the frozen post-result auditor
was then invoked exactly once.  Re-running that auditor would violate its
declared protocol and is therefore intentionally omitted from the command list.

## Directory map

- `notes/research_contract.md`: claim, overlap, and stop/go policy.
- `notes/theorem_program.md`: proof obligations and evidence levels.
- `notes/continuum_g1_design.md`: exact quotient and numerical acceptance gates.
- `notes/discovery_protocol.md`: result-blind frozen 207,025-state discovery protocol.
- `notes/manual_review_protocol.md`: separately frozen post-result diagnostic boundary.
- `notes/pde_mixed_jet_theorem.md`: proved weak-budget continuum mixed-jet and
  conditional fold/cusp/rank persistence theorem, with finite-budget limits.
- `notes/direct_physical_multimode_theorem.md`: audited direct theorem for each
  fixed finite integer $d\ge2$ and prescribed fixed finite mode count in a
  $d$-, $m$-, and epsilon-dependent physical slab family, including its
  sequential-limit, non-uniform-in-$d$, and event-mass limits.
- `notes/exact_m_mode_encounter_theorem_candidate.md`: archived attacked v1;
  Round 112 identified the false crossover-complement dominance step.
- `notes/exact_m_mode_encounter_theorem_v2.md`: repaired exact-$m$ global
  topology and fixed-$\varepsilon$ weak-budget Doi theorem; independently
  accepted by Rounds 118 and 120 at SHA `e78a0d77959d50214d56ef4708a20ac465232883fbbdd4ee42fe488c0b95c85d`.
  Its original candidate-status prose is intentionally preserved because those
  accepted bytes are immutable; Round 149 separately accepts the migrated
  paper proof.
- `notes/modal_certificate_theory_and_prr_redirect.md`: repaired
  box-and-complement modal-certificate theorem and theorem-first route.
- `notes/positive_b_fixed_control_robustness_design_v2.md`: active no-refit F0
  design for exact-rational same-budget one-/two-/three-mode candidates; no
  primary positive-$B$ command is currently authorized.
- `notes/verified_semigroup_enclosure_design.md`: selected directed-
  uniformization enclosure.  Round 150 introduced the first bounded directed
  packed-action primitive; Round 152 rejected those bytes, and independent
  Round 155 accepted the repaired Round-154 bytes only as a bounded primitive.
  Rate-interval composition,
  uniformization, Poisson tails, jets, topology, independent replay, and
  production resources remain open.
- `notes/f1_to_f2_common_observable_selector_v1.md`: pre-F1 mechanical common-
  cut/window, uncertainty, multiplicity, power, and RNG design.  The selector-v2
  implementation and its tested-macOS process/resource surface are accepted by
  Rounds 151/153; second-POSIX portability, a causal second-parent contention
  handshake, and all F1/F2 science remain open.
- `notes/continuum_next_stage_path.md`: theorem-first claim ladder and the
  pre-science, 36-row deterministic, continuum-envelope, off-lattice, audit,
  and manuscript branches for the next physical-`d=2` stage.
- `notes/continuum_research_program_v2.md`: strict-continuum C0--C3 and root-
  transfer contract.  It now distinguishes the ideal analytic SG form from
  production interval centres and freezes the exact-adjoint `P_h` denominator.
- `notes/continuum_c1_fixed_1d_free_ou_mosco_candidate.md`: repaired
  fixed-box ideal one-dimensional free-OU Mosco/strong-resolvent proof
  candidate, with arbitrary-sequence liminf, diagonal recovery, exact map
  algebra, and production-boundary exclusions; fresh independent acceptance
  remains open.
- `notes/continuum_c1_free_form_and_functional_bridge_candidate.md`: result-
  blind successor proof candidate for the relative, periodic, tensor-product,
  vertex-dual, and physical-volume killing forms, followed by a self-contained
  varying-space resolvent-to-positive-time functional bridge.  It proves only
  the abstract implication under stated premises; complete C1, the production
  application bridge, rates, and release remain false.
- `notes/continuum_c1_varying_space_resolvent_mosco_candidate.md`: 571-line
  self-contained theorem candidate turning one reconstructed resolvent limit
  and near-isometric adjoint maps into generalized Mosco convergence, with
  conditional free-tensor and bounded-killing corollaries.  Its final local
  exact-byte audits have `P0=P1=P2=0`, but model-specific C1 remains open.
- `notes/continuum_c1_production_gauge_killing_bridge_design_v1.md`: audited
  two-stage DESIGN for a global-gauge, common-flux, physical-mass, and
  reconstructed-killing application bridge with acyclic source/receipt
  provenance.  No symbolic contract or production application exists yet.
- `notes/continuum_c2_quantitative_positive_time_route_candidate.md`:
  conditional fixed-box C2 route from a sharp cut-layer form defect through
  complex-sector resolvents and positive-time Dunford transfer.  Its
  conservative `h^(1/2)` target is not a proved or production-bound rate.
- `notes/reproducibility_environment.md`: exact direct Python baseline,
  environment-only verification command, and the still-open clean-install and
  transitive-lock boundary.
- `notes/f0_rate_interval_composition_next_stage.md`: Round-155-cleared
  next-stage design for composing centre-action boxes with exact stage-1 rate
  witnesses in a point-plus-$l^1$-ball representation before any Poisson
  propagation; the bounded primitive is accepted, while F0 remains held.
- `notes/weak_budget_design_protocol.md`: result-informed free-exposure cusp
  reproduction and complete sampled-simplex boundary.
- `notes/g1c_simplex_protocol.md`: prospectively frozen result-informed full-simplex
  finite-grid discovery protocol.
- `notes/g1d_fold_confirmation_protocol.md`: frozen one-segment finite-budget
  fold confirmation protocol.
- `notes/observable_four_patch_protocol.md`: result-informed exact-continuum
  physical-$d=2$ four-slab cusp and relative-shape confirmation protocol.
- `notes/observable_four_patch_d3_protocol.md`: result-informed exact sphere-
  kernel physical-$d=3$ analogue with a direct spherical-coordinate cross-check.
- `notes/broad_patch_b0_bridge_protocol.md`: separately frozen broad-patch
  exact-kernel-to-four-mesh $B=0$ bridge; it does not claim positive $B$.
- `notes/positive_b_broad_four_slab_protocol.md`: disclosed low-mesh budget
  selection and frozen held-out-mesh protocol for the fixed broad four-slab
  positive-$B$ killed-Doi test.
- `notes/positive_b_postresult_audit_protocol_v2.md`: frozen exactly-once
  independent post-result reconstruction and reporting boundary.
- `notes/literature_gap_20260713.md`: primary-literature collision and novelty audit.
- `code/validate_gig_constructive.py`: deterministic reduced-model pilot.
- `code/continuum_g1_smoke.py`: exact-quotient low-resolution operator smoke.
- `code/build_manuscript_inputs.py`: fail-closed generation of manuscript TeX
  macros from the release-pinned $d=2/d=3$ four-slab, broad-bridge, G1c, and
  G1d JSON artifacts and their nested source chains.  It uses descriptor-level
  same-byte snapshots for the release manifest and all 38 unique/reused source
  roles, enforces exact per-family schemas and role cardinalities, rejects
  non-finite or duplicate-key JSON and recursive claim promotion, and renders
  only from the already-verified immutable payloads.
- `code/build_positive_b_manuscript_input.py`: separate fail-closed TeX macro
  generation from the canonical result, two-process record, exactly-once audit,
  and all 14 frozen provenance pins for the fixed-control positive-$B$ point. It
  reads ordinary nonsymlink files through same-byte descriptor snapshots and
  independently reconstructs all 24 per-mesh gates and all five mesh-agreement
  gates, including saved-trace extrema, root brackets, probability domains, and
  scan/tail junctions.
- `code/plot_weak_budget_design.py`: byte-reproducible vector figure for the
  result-informed $B=0$ diagnostic; it recomputes every plotted value.
- `code/plot_observable_four_patch.py`: source-pinned physical-$d=2$ relative-
  shape figure; its human-readable labels make no event-mass claim.
- `code/plot_d2_d3_four_patch.py`: deterministic vector comparison of the
  physical-$d=2$ disk and physical-$d=3$ sphere $B=0$ relative shapes.
- `code/plot_positive_b_broad_four_slab.py`: deterministic, claim-scoped
  fixed-control $B=0.01$ density/root and event-basin figure; the PDF and its
  source-pinned metadata sidecar are published as one rollback-safe pair. Its
  visible scope distinguishes the $t\leq35$ root screen from the $t\leq100$
  basin-mass/tail checks and disclaims post-$35$ root exclusion.
- `code/compile_manuscript.py`: clean temporary LaTeX build, PDF hygiene gate,
  strict per-figure metadata/claim/source-role contracts, same-byte input
  snapshots, and a rollback-safe multi-output publication transaction for the
  archived historical working set.
- `code/compile_theorem_first_working.py`: active analytical-only compiler with
  a closed source allowlist, four isolated builds, byte-identity gates, TeX/PDF/
  font/text checks, normalized reproducible logs, and rollback-safe publication.
- `code/rate_defined_tensor_f0_packed_interval_action.py`: Round-154-repaired
  science-free packed interval action for frozen-order $P^T$ and signed $Q^T$,
  with per-operation outward rounding, source/kernel/input hash bindings,
  owned read-only outputs, and a `16N+81B` fixed-payload ledger.  This is an
  implementation primitive accepted for the repaired Round-154 bytes by the
  independent Round-155 re-audit, not F0 acceptance.
- `code/rate_defined_tensor_f0_production_initial_stream.py` and its separate
  rebuild/independent/geometry verifiers: exact-schema 12-row control-free
  source, partition, marginal, free-axis-rate, sparse-box, and native packed-
  axis preparation.  The accepted scope contains no killing, full operator,
  propagation, topology, positive-budget value, or F0 result.
- `code/rate_defined_tensor_f0_production_initial_clean_replay.py`: standard-
  library outer observer that runs two complete serialized repeats, each with
  five separate `python -I` processes, and retains a pinned receipt.  This is
  process-boundary replay on one runtime, not hermetic or cross-backend
  independence.
- `code/test_living_scope_consistency.py`: regression guard that keeps the
  README, research contract, theorem program, focused rewrite blueprint, and
  working manuscript aligned on the fixed-point result and its open gates.
- `code/continuum_c1_sg_manufactured.py` and its two test modules: neutral
  single-axis v2 map/form diagnostic, exact flat affine/quadratic/interpolant
  sentinels, raw-primitive interval containment, explicit failure of the
  gauge-scaled form-containment bridge, and mutation attacks.  Passing this
  diagnostic is not a Mosco proof or a production-centre limit.
- `code/build_continuum_c1_ideal_refinement_contract_candidate_v1.py`, its
  standalone verifier, note pin, and three test modules: result-blind,
  fail-closed machine contract for the prospective ideal refinement families,
  tensor gauge, physical-volume killing, and conditional functional bridge.
  Its finite configurations are structural anchors, not a convergence
  sequence, and every promotion flag remains false.
- `code/continuum_c1_free_axes_tensor_diagnostic.py` and its two test modules:
  neutral numerical fixture for midpoint, vertex-dual, periodic, and separable
  tensor identities.  It streams exact factorized checks without allocating a
  three-dimensional array and is not production evidence.
- `code/build_continuum_c2_cut_layer_neutral_fixture_v1.py`, the independent
  integer validator, two test suites, and currentness gate: exact-rational
  neutral cut-cell fixture with a machine-checked Machin upper bound for pi,
  strict JSON types, 20 frozen rows, and 97/97 assertions.  It computes no
  contact fractions, controls, budgets, semigroups, or production values.
- `artifacts/data/continuum_c0_model_contract_candidate_v1.json` and its old
  verifier/tests: immutable historical C0-v1 bytes.  Only the dedicated
  current-staleness sentinel belongs to the current suite; the old 6/6 and
  12/12 results apply only to their then-pinned sources.
- `artifacts/data/continuum_c0_mathematical_source_v2.json`,
  `continuum_c0_control_method_commitment_v2.json`, and
  `continuum_c0_model_contract_candidate_v2.json`: C0-only mathematical and
  method commitments plus the deterministic current semantic candidate.  The
  method commitment intentionally contains no control values or payload path.
- `code/build_continuum_c0_model_contract_candidate_v2.py`,
  `validate_continuum_c0_model_contract_candidate_v2.py`, and the three C0-v2
  test modules: one-shot producer, independent same-byte/source-pinned
  verifier, currentness checks, and mutation attacks.  Their PASS does not
  close complete C0 or the production gauge/application bridge.
- `artifacts/data/continuum_c0_measure_partition_preconditions_v1.json` and
  `continuum_c0_model_contract_candidate_v3.json`: canonical well-definedness
  preconditions and the immutable versioned wrapper over the v2 semantic base;
  the wrapper keeps complete C0, the production gauge bridge, and release
  false.
- `code/build_continuum_c0_model_contract_candidate_v3.py`,
  `validate_continuum_c0_model_contract_candidate_v3.py`, and the two C0-v3
  test modules: reproducible wrapper, independent semantic/geometry verifier,
  actual-versus-declared source-open check, and adversarial mutations over all
  36 axes and 34,787,462 tensor cells.
- `audits/continuum_c0_model_contract_v3_adversarial_round3_20260717.md`:
  hash-specific v1-to-v3 chronology, mathematical well-definedness review,
  code hardening rounds, exact test/compile receipts, and retained C0/C1/PRR
  HOLD boundaries.
- `manuscript/encounter_multimodal_prr.tex`: claim-gated historical working
  draft; it still contains the superseded at-least-`m` theorem wording and is
  not the theorem-first source.
- `manuscript/exact_m_theorem_spine.tex`: independently accepted reader-facing
  exact-`m` theorem fragment, with compact-window and sequential-limit
  restrictions explicit.
- `manuscript/exact_m_theorem_full_proof.tex`: complete reader-facing proof of
  the common-variance zero bound, adjacent isolation, exact pure topology,
  posterior-sector complement, slow-factor transfer, and fixed-$\varepsilon$
  Doi embedding; frozen and independently accepted in Round 149.
- `manuscript/encounter_multimodal_prr_theorem_first_working.tex`: separate
  theorem-first working source whose seven-page PDF now includes the audited
  physical-`d=2` C0-A quotient and natural-decay operator realization plus the
  exact-`m` spine; it imports no generated positive-`B` result macros and makes
  no new finite-parameter topology or finite-volume-to-continuum claim.
- `output/pdf/encounter_multimodal_prr_theorem_first_working.pdf`: rendered
  theorem-first working PDF from two byte-identical isolated builds.
- `manuscript/encounter_multimodal_prr_supplement.tex` and
  `output/pdf/encounter_multimodal_prr_theorem_first_supplement_working.pdf`:
  twenty-four-page analytical working Supplement and its byte-reproducible
  rendered PDF.  Proposition S3.3 states the conditional varying-space
  positive-time bridge; Sec.~S4 remains a distinct, more general at-least-`m`
  result, and Sec.~S5 contains the complete exact-`m` proof accepted for its
  frozen bytes in Round 149.
- `manuscript/inputs/positive_b_results.tex`: generated fixed-control-only
  positive-budget values; its header explicitly forbids cusp, continuum,
  independent-solver, and PRR-ready promotion.
- `artifacts/data/manuscript_compile.json`: archived 13-page historical-build
  record.  It preserves its original source/bibliography/PDF hashes, is marked
  `ARCHIVED_HISTORICAL_WORKING_SET`, and is superseded by the theorem-first
  manifest while remaining `release_eligible=false`.
- `artifacts/data/theorem_first_working_compile.json`: source/PDF hashes and
  compile, text, PDF-structure, and publication record for the active 7+24-physical-page
  theorem-first main/Supplement working set; `release_eligible=false`, with both
  positive-budget evaluation flags false.
- `artifacts/data/continuum_c1_sg_manufactured_v1.json`: immutable first-round
  neutral diagnostic retained for its historical audit hash.
- `artifacts/data/continuum_c1_sg_manufactured_v2.json`: current neutral
  single-axis diagnostic with uniform cell-mass, exact-adjoint map, ideal edge-
  interpolant, density-ratio, boundary-order, and production-centre residual
  ledgers; all C1/production-limit/release flags remain false.
- `artifacts/data/continuum_c1_ideal_refinement_contract_candidate_v1.json`:
  result-blind C1 ideal-refinement/rate contract candidate pinned to the
  audited mathematical successor note and C0-only sources; all complete-C1,
  production, C2/C3, and release booleans are false.
- `artifacts/data/continuum_c1_free_axes_tensor_diagnostic_v1.json`: neutral
  finite-grid identity and order fixture for free axes and tensor
  factorization; its twelve rows are diagnostic anchors only.
- `artifacts/data/continuum_c2_cut_layer_neutral_source_v1.json`,
  `continuum_c2_cut_layer_neutral_fixture_v1.json`, and
  `continuum_c2_cut_layer_neutral_fixture_currentness_v1.json`: result-blind
  unit-torus cut-layer source, exact 20-row fixture, and six-file hash gate.
  The finite `9/4` value is not a theorem constant; complete C2 remains false.
- `audits/continuum_c1_sg_manufactured_round1_20260717.md`: immutable v1
  diagnostic boundary and first mutation-sentinel record.
- `audits/continuum_c1_fixed_1d_mosco_repair_round2_20260717.md`: hash-specific
  proof/code attack, gauge-containment P1 repair, executable interpolant
  sentinel, C0-v1 staleness boundary, and local scoped `P0=P1=P2=0` re-audits.
- `audits/continuum_c1_refinement_functional_bridge_round4_20260717.md`:
  Round-4 hash-specific chronology for the successor proof candidate, machine
  contract, neutral free-axis/tensor fixture, conditional manuscript
  integration, and retained complete-C1/C2/C3/release HOLD boundary.
- `audits/continuum_c1_varying_space_resolvent_mosco_round5_20260717.md`:
  Round-5 hash-specific attacks on unitarization, all resolvent shifts, the
  dual liminf formula, recovery diagonal, asynchronous finite tensor products,
  and bounded physical-volume multipliers; complete C1 remains HOLD.
- `audits/continuum_c1_production_gauge_killing_bridge_design_round6_20260717.md`:
  Round-6 design-only audit of the global gauge, common flux, physical
  normalization, reconstructed killing, and acyclic evidence architecture.
- `audits/continuum_c2_quantitative_positive_time_route_round7_20260717.md`:
  Round-7 theory/fixture audit, including the pi-certificate and numeric-alias
  repair chronology, final 97/97 executable assertions, and retained C2 HOLD.
- `artifacts/data/physical_production_initial_stream_v1/`: canonical 12-row,
  206-entry file-backed source/partition/free-axis/sparse-box bundle.
- `artifacts/data/physical_production_initial_stream_v1_relational_receipt.json`,
  `_independent_receipt.json`, and `_geometry_receipt.json`: same-core,
  separately implemented semantic, and packed-axis geometry joins.  The last
  establishes only forward/back free-axis rate payloads tied to exact
  partition and axis-relation hashes; it does not establish killing or the
  full generator.
- `artifacts/data/physical_production_initial_clean_process_replay_v1.json`:
  two-repeat outer-process receipt with ten distinct observed PIDs and explicit
  negative promotion flags for F0, continuum, and positive-budget science.
- `manuscript/SUBMISSION_METADATA_REQUIRED.md`: hard no-submit checklist.
- `manuscript/README.md`: human-facing source/PDF pointer.  Only the
  theorem-first main and Supplemental working set is active; the similarly
  named 13-page manuscript is an archived historical reconstruction and must
  not be uploaded as the current paper.
- `artifacts/data/gig_constructive_pilot.json`: machine-readable G0 evidence.
- `artifacts/data/manuscript_numerical_sources_manifest.json`: fail-closed
  release manifest for all five current numerical result families, including
  manifests, producers, tests, protocols, dependencies, and the G1d-to-G1c pin.
- `artifacts/data/continuum_g1_smoke.json`: machine-readable G1a smoke evidence.
- `artifacts/data/continuum_g1_discovery_manifest.json`: frozen G1b discovery inputs.
- `artifacts/data/continuum_g1_discovery_result.json`: completed formal line evidence.
- `artifacts/data/continuum_g1_manual_review_result.json`: five-times-finer
  time-sampling diagnosis at the flagged control.
- `artifacts/data/continuum_weak_budget_design_result.json`: discrete $B=0$
  free-exposure cusp and 5,151-control screen; all continuum/finite-$B$ flags false.
- `artifacts/data/continuum_g1c_simplex_manifest.json`: byte-pinned 66-control
  G1c design; a candidate can seed only a separately frozen confirmation.
- `artifacts/data/continuum_g1d_fold_confirmation_result.json`: one audited
  $B=0.6$, 207,025-state finite-grid fold with the complete mixed fold jet.
- `artifacts/data/continuum_observable_four_patch_result.json`: byte-reproducible
  exact-kernel four-slab cusp and three-maximum/two-minimum confirmation; all
  interval, finite-$B$, and project claim flags remain false.
- `artifacts/data/continuum_observable_four_patch_d3_result.json`: byte-identical
  exact sphere-kernel physical-$d=3$ confirmation with a non-Bessel spherical-
  coordinate cross-check; finite-$B$/independent-PDE/project flags remain false.
- `artifacts/data/continuum_broad_patch_b0_bridge_result.json`: result-informed
  broad-patch $B=0$ exact-kernel/four-mesh bridge; positive-$B$ and unbounded-box-
  limit flags remain false.
- `artifacts/data/positive_b_broad_four_slab_result.json`: canonical fixed-control
  $B=0.01$ two-odd-mesh result with five alternating simple stationary roots on
  the saved screen through $t=35$, three positive basin reaction masses and tail
  checks through $t=100$, no post-$35$ root exclusion, and all continuum/project
  flags false.
- `artifacts/data/positive_b_broad_four_slab_reproducibility.json`: internally
  consistent two-process byte-identity and canonical-promotion record; the
  post-result auditor did not witness the two historical subprocesses.
- `artifacts/data/positive_b_broad_four_slab_independent_audit.json`: frozen
  exactly-once algebraic reconstruction of the saved canonical evidence; it is
  not an independent semigroup or solver rerun.
- `artifacts/figures/positive_b_broad_four_slab.pdf` and its `_metadata.json`
  sidecar: manuscript-ready rendering of the fixed-control result, pinned to
  the canonical result, reproducibility record, independent audit, plotter,
  and plot tests; the figure states all negative scope boundaries on-page.
- `audits/round_03_g1_smoke_attack.md` and `audits/round_03_resolution.md`:
  mutation attack and closure evidence for G1a.
- `audits/round_16_g1c_prerun_audit.md`, `audits/round_17_weak_budget_audit.md`,
  and `audits/round_19_pde_theory_resolution.md`: independent pre-run,
  numerical, and theorem-resolution gates.
- `audits/round_23_direct_multimode_theory_attack.md`: repaired adversarial
  audit of the direct physical fixed-finite-mode theorem.
- `audits/round_25_g1d_fold_audit.md` and
  `audits/round_26_g1d_audit_resolution.md`: independent fold reconstruction
  and the fail-closed resolution of two portability/root-scope P2 findings.
- `audits/round_25_observable_four_patch_self_audit.md`: independent real-jet,
  root, quadrature, and claim-boundary reconstruction of the four-slab result.
- `audits/round_28_observable_four_patch_d3_self_audit.md`: physical-$d=3$
  representation, convergence, reproducibility, and claim-boundary audit.
- `audits/round_61_allocation_v2_independent_prerun_attack.md`,
  `audits/round_64_allocation_v3_repair_freeze.md`, and
  `audits/round_74_allocation_v3_independent_prerun_attack.md`: allocation-cusp
  attack/repair history.  The fresh v3 attack found one P0 and six P1 defects;
  no $65/97$ scientific run is authorized until a repaired version passes a
  new independent pre-run audit.
- `audits/round_59_positive_b_canonical_result_closure.md` and
  `audits/round_60_positive_b_closure_independent_reaudit.md`: canonical
  positive-budget closure, independent hash/arithmetic reconstruction, tight-
  margin disclosure, and the fixed-control-only claim boundary.
- `audits/round_63_positive_b_figure_closure.md` and
  `audits/round_66_positive_b_figure_provenance_addendum.md`: deterministic
  vector-figure closure, visual QA, five-role source provenance, and atomic
  PDF/metadata publication tests without rerunning the scientific auditor.
- `audits/round_67_stageb_v3_independent_attack.md`,
  `audits/round_69_stageb_v4_design_resolution.md`,
  `audits/round_70_stageb_v4_independent_attack.md`, and
  `audits/round_72_stageb_v5_design_resolution.md`: repeated Stage-B design
  attacks and v5 repair.
- `audits/round_73_stageb_v5_independent_attack.md`: independent exact-arithmetic
  attack with P0=P1=P2=0 and verdict `ACCEPT-DESIGN / HOLD-EXECUTION`.  It
  authorizes only construction and independent audit of the synthetic T0
  selector package; no Stage-A, Stage-B, or off-lattice science is authorized.
- `audits/round_68_positive_b_main_integration_independent_attack.md`: the
  independent manuscript-integration HOLD that triggered strict same-byte
  source snapshots, reconstructed numerical gates, figure-metadata contracts,
  and explicit $t=35$ versus $t=100$ wording.
- `audits/round_71_positive_b_main_integration_closure.md`: independent
  P0=P1=P2=0 closure of that integration scope, including 97/97 focused tests,
  static analysis, immutable verified input snapshots, and byte-identical
  clean PDF builds.  Its verdict is `ACCEPT-MAIN-INTEGRATION` only; allocation
  cusp, continuation, independent killed-process, and PRR promotion remain
  held.
- `audits/round_77_general_dimension_theory_attack.md` and
  `audits/round_79_general_dimension_repair.md`,
  `audits/round_82_general_dimension_independent_postedit_attack.md`, and
  `audits/round_84_general_dimension_scope_repair.md`: mathematical
  admissibility, proof/scope promotion, independent detection of one surviving
  dimension-specific contact phrase, and its explicit $d$-ball/unit/test
  repair.  Promotion remains held for an independent post-fix recheck and does
  not add numerical support beyond physical $d=2,3$.
- `audits/round_149_exact_m_supplement_migration_independent_attack.md`:
  hash-specific independent acceptance of the complete paper proof and
  theorem-first 5+20-page build (`P0=P1=P2=0`), without finite-parameter or PRR
  promotion.
- `audits/round_151_selector_orphan_test_race_repair.md`: withdraws the
  Round-147 macOS lock P1 as a harness false positive, accepts the final
  process-lifetime/resource surface on the tested runtime, and retains one
  second-POSIX portability P2.
- `audits/round_153_selector_round151_independent_attack.md`: independent
  read-only closure of the final selector/test bytes (`P0=P1=0`), including 45
  fresh orphan-lock probes and the full 142-test suite; it retains second-POSIX
  and causal-contention-handshake P2 items.
- `audits/round_150_f0_packed_directed_action_stage.md`: implementation and
  self-audit of the bounded packed directed-action primitive (56 small-state
  tests); production F0 and independent acceptance remain held.
- `audits/round_152_f0_packed_directed_action_independent_attack.md`: rejects
  the Round-150 bytes after reproducing a bound-runtime stride-2 Boolean ufunc
  defect at production-relevant block sizes; it also requires heterogeneous
  saved oracles and preserves fresh-verifier/runtime-probe P2 boundaries.
- `audits/round_154_f0_packed_directed_action_repair.md`: repairs the validator
  P1 with contiguous scratch, adds vectorized runtime probes, heterogeneous
  exact oracles, and a consistency digest while keeping F0 held.
- `audits/round_155_f0_packed_directed_action_independent_reaudit.md`:
  independently accepts the repaired bytes only as a bounded implementation
  primitive; 99 fresh block-size processes and 320 heterogeneous exact rows
  pass, while authentication/fresh verifier and all later F0 stages stay open.
- `audits/round_167_production_initial_stream_clean_replay_and_continuum_erratum.md`:
  hash-specific closure of the 12-row control-free source/partition/free-axis
  bundle, packed-axis joins, two-repeat clean serialized replay, manuscript
  integration, and the Round-165 reversible-density erratum.  It keeps killing,
  the full generator, production resource evidence, F0, continuum topology,
  positive-budget science, and release explicitly open.
- `audits/round_168_production_killing_geometry_strict_full_freeze.md`:
  independently audits the regenerated exact-full producer and 76-file bundle
  at `P0=0`, `P1=0`, `P2=2`, accepting it only as input to the separate-source
  verifier.  It records 227,693 exact-zero, 4,142 exact-unit and 1,304 partial
  contact cells while keeping concrete killing, operator assembly, F0/F1,
  continuum and release held.

## Non-negotiable reporting rules

Every claimed mode must be supported by isolated alternating roots of
`f_t`, nonzero curvature margins, a prominence threshold, and a tail/root
isolation interval.  A cusp alone does not prove trimodality: a remote
maximum--minimum pair must also persist.  Fold transfer requires the relevant
joint third-order jets; cusp transfer requires the relevant fourth-order jets.
The word `root_count` in a sampled sign-change screen is never an
interval-exhaustive exclusion of tangential or sub-grid roots.  A free-exposure
relative-shape pass is never relabeled as positive-$B$ event-mass evidence.  In
the fixed positive-budget record, root support ends with the saved $t\leq35$
screen, whereas event-mass and tail support ends at $t=100$; neither is an
interval proof and the latter does not exclude post-$35$ extrema.
