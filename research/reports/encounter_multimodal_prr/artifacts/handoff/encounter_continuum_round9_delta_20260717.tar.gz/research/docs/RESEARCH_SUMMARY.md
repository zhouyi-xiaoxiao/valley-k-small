# RESEARCH SUMMARY

最后更新: 2026-07-17

## 仓库定位
- 本仓库研究随机游走首达时间分布中的双峰、谷值、shortcut 机制与跨模型对比。
- `research/` 是研究主树，包含报告、研究文档与历史归档。
- `platform/` 承载网站、schema、自动化与 agent handoff 工具。
- `scripts/reportctl.py` 是唯一 Python CLI 入口。

## 当前主线
- Ring 系列:
  - `ring_lazy_flux`, `ring_lazy_jump*`, `ring_valley*`, `ring_two_target`, `ring_two_walker_encounter_shortcut`
  - 关注 lazy / non-lazy ring、shortcut 注入方式、峰谷判据与双峰窗口
- Grid2D 系列:
  - `grid2d_*`
  - 关注 corridor、rectangular geometry、two-target、reflecting / blackboard 等结构下的 valley 与 bimodality
- Cross-model:
  - `cross_luca_regime_map`
  - 关注跨模型 regime map、公平比较与 transfer 条件
- Encounter publication:
  - `encounter_heterogeneous_catalytic`
  - 关注有限 CTMC 的 Green/Woodbury 降维、空间异质反应与 2D/多维模态机制，并明确连续极限的证据边界
  - `encounter_multimodal_prr`
  - 独立 PRR theorem-first 主线：exact-`m` 分析骨架已冻结，当前严格区分 ideal analytic SG 连续极限与 production interval/roundoff；C1 仍为 HOLD

## 建议阅读顺序
1. `research/reports/README.md`
2. `research/reports/report_registry.yaml`
3. 目标报告目录下的 `README.md`、`notes/`、`manuscript/`
4. 若需要交付或 agent 消费，再看 `platform/README.md`

## 研究与平台入口
- 人类阅读:
  - `research/docs/README.md`
  - `research/reports/README.md`
  - `platform/README.md`
- agent 入口:
  - `AGENTS.md`
  - `platform/skills/valley-k-small-continuation/`

## 常用命令
- `python3 scripts/reportctl.py list`
- `python3 scripts/reportctl.py resolve --report ring_valley_dst`
- `python3 scripts/reportctl.py build --report ring_valley_dst --lang cn`
- `python3 scripts/reportctl.py summary`
- `python3 scripts/reportctl.py doctor`
- `python3 scripts/reportctl.py agent-sync`
- `python3 scripts/reportctl.py agent-pack`

## 最新进展（手动追加）
- 仓库已收敛为 canonical 结构：`research/`、`platform/`、`packages/`、`scripts/`、`tests/`。
- 根目录兼容入口正在被移除，agent handoff 改为通过生成包输出到 `.local/deliverables/agent_pack/v1`。
- 文档、测试与 CLI 正在同步切换到单一 `reportctl` 表面。
- `encounter_multimodal_prr` 已形成 result-blind C0-v2 语义基座与不可变 C0-v3 well-definedness wrapper：冻结 exact-adjoint `P_h`、`A_h/S_h` 分工、全局质量 gauge、正质量/非零分母前提，并精确复核 12 个 configuration、36 条轴、4 条 endpoint-half-volume 轴、2 条 wrapped periodic row 和 34,787,462 个 tensor cell；聚焦 C0 实现层 86/86 本地通过，但 exact control source、raw-to-gauged production bridge、完整 C0 与 release 均仍为 HOLD。Round 4 又完成一个 706 行、同字节终审 `P0=P1=P2=0` 的 C1 后继证明候选，覆盖 relative/periodic/tensor/vertex/physical-volume killing，并把“重构 resolvent 前提推出正时间函数演算与 moving pairings”作为条件式 Proposition S3.3 纳入 7 页正文 + 24 页补充材料；配套 result-blind contract 与 neutral free-axis/tensor fixture 均不自我晋级。完整 C1、production bridge、定量 C2、box C3、root transfer 与 PRR release 继续严格 HOLD；这些均是本地 hash-specific 开发审计，不是外部接受。
- `encounter_multimodal_prr` Round 5 补上 571 行的 varying-space reconstructed-resolvent-to-Mosco 自包含定理：以 `U_h=J_h(P_hJ_h)^{-1/2}` 精确等距化，用 resolvent 变分不等式和谱对偶公式证明 liminf，再以 `beta(L_h+beta)^{-1}U_h^*` 作 recovery；主定理与 tensor/killing 三路终审均为 `P0=P1=P2=0`。这只关闭抽象 free-tensor Mosco/有界 killing 条件蕴含，真实 refinement sequences、control-specific averages、production gauge/application、C2/C3 与 complete C1 仍为 HOLD。
- `encounter_multimodal_prr` Round 6/7 已把下一阶段拆成两个诚实层次：Round 6 的 883 行 production bridge 设计固定单一 global mass gauge、共同 exact flux、物理 quotient measure/`W^-1`、离散 `B*V` 与重构 `B*K` 的区别，以及无环 source/receipt 证据架构；两路终审为 `P0=P1=P2=0`，但 machine contract 与 production application 尚未实现。Round 7 的 539 行条件性 C2 路线把 sharp cut-layer 的保守 `O(h^(1/2))` form defect 接到 complex-sector reconstructed resolvent 与 `tau>0` Dunford transfer；配套 result-blind unit-torus fixture 以 Machin 有理证书、独立整数计数、严格 JSON 类型和 currentness gate 通过 97/97 assertions 加两个直接入口，并经两路终审 `P0=P1=P2=0`。这只验证中性几何夹具；QF1--QF2、source-bound sector rate、complete C1/C2、C3 与 release 继续 HOLD。
- `encounter_multimodal_prr` Round 8 已冻结 neutral symbolic-bridge schema/contract fixture：builder 与独立 validator 分别重算 global gauge `1/4`、共同 flux `6/5`、tensor conductance `6/7`、`K=1/3`、物理权重 `1/10` 及正区间商 `[15/13,31/25]`；static/mutation/currentness 共 59/59 assertions 加两个直接入口通过。终审发现并修复 currentness 并发替换旧 inode 的 P1，最终十文件两路只读复核均为 `P0=P1=P2=0`。这仍不是 production candidate：11 个 production roles 未绑定，formal symbolic candidate、independent receipt、correlated ideal member、complete C0--C3、science/release 全部为 false。
- `encounter_multimodal_prr` Round 9 对 QF2 本身做了 exact no-go 审计：标准 nodal tensor-`Q1` 的 all-discrete-pairs `O(h)` graph-form defect 在 `d>=2` 为假，实际 vertex-dual Neumann × vertex-dual Neumann × periodic 对齐也有同一 checkerboard 障碍，三维所需常数按 `8/(9h)` 发散。精确有理数 fixture 通过 90/90 并经独立 `P0=P1=P2=0` 审计。新候选路线改为 regular continuum resolvent solution 的单边 control-volume residual；sharp killing 用 `H2 -> L-infinity` 与 `L2` cut-layer 误差，因此 QF1 不再卡主链，但 free SG residual、source-bound map/geometry、mixed-boundary sector `H2` 与 contour growth 仍开放，complete C2/C3/release 仍为 false。

## 自动索引（由脚本生成）
<!-- AUTO-INDEX:START -->
| report | pdfs | tex |
| --- | --- | --- |
| `research/reports/ring_lazy_jump` | `research/reports/ring_lazy_jump/manuscript/ring_lazy_jump_cn.pdf`, `research/reports/ring_lazy_jump/manuscript/ring_lazy_jump_en.pdf` | `research/reports/ring_lazy_jump/manuscript/ring_lazy_jump_cn.tex`, `research/reports/ring_lazy_jump/manuscript/ring_lazy_jump_en.tex` |
| `research/reports/ring_lazy_jump_ext` | `research/reports/ring_lazy_jump_ext/manuscript/ring_lazy_jump_ext_cn.pdf`, `research/reports/ring_lazy_jump_ext/manuscript/ring_lazy_jump_ext_en.pdf` | `research/reports/ring_lazy_jump_ext/manuscript/ring_lazy_jump_ext_cn.tex`, `research/reports/ring_lazy_jump_ext/manuscript/ring_lazy_jump_ext_en.tex` |
| `research/reports/ring_lazy_jump_ext_rev2` | `research/reports/ring_lazy_jump_ext_rev2/manuscript/ring_lazy_jump_ext_rev2_cn.pdf`, `research/reports/ring_lazy_jump_ext_rev2/manuscript/ring_lazy_jump_ext_rev2_en.pdf`, `research/reports/ring_lazy_jump_ext_rev2/manuscript/extras/fig2_overlap_binbars_beta0.01_x1350_description_en.pdf` | `research/reports/ring_lazy_jump_ext_rev2/manuscript/ring_lazy_jump_ext_rev2_cn.tex`, `research/reports/ring_lazy_jump_ext_rev2/manuscript/ring_lazy_jump_ext_rev2_en.tex` |
| `research/reports/ring_lazy_flux` | `research/reports/ring_lazy_flux/manuscript/ring_lazy_flux_cn.pdf`, `research/reports/ring_lazy_flux/manuscript/ring_lazy_flux_en.pdf` | `research/reports/ring_lazy_flux/manuscript/ring_lazy_flux_cn.tex`, `research/reports/ring_lazy_flux/manuscript/ring_lazy_flux_en.tex` |
| `research/reports/ring_valley` | `research/reports/ring_valley/manuscript/ring_valley_en.pdf` | `research/reports/ring_valley/manuscript/ring_valley_en.tex` |
| `research/reports/ring_valley_dst` | `research/reports/ring_valley_dst/manuscript/ring_valley_dst_cn.pdf`, `research/reports/ring_valley_dst/manuscript/ring_valley_dst_en.pdf` | `research/reports/ring_valley_dst/manuscript/ring_valley_dst_cn.tex`, `research/reports/ring_valley_dst/manuscript/ring_valley_dst_en.tex` |
| `research/reports/ring_deriv_k2` | `research/reports/ring_deriv_k2/manuscript/ring_deriv_k2_en.pdf`, `research/reports/ring_deriv_k2/manuscript/extras/note_k2.pdf`, `research/reports/ring_deriv_k2/manuscript/extras/note_rewire_lazy.pdf` | `research/reports/ring_deriv_k2/manuscript/ring_deriv_k2_en.tex`, `research/reports/ring_deriv_k2/manuscript/extras/note_k2.tex`, `research/reports/ring_deriv_k2/manuscript/extras/note_rewire_lazy.tex` |
| `research/reports/ring_two_target` | `research/reports/ring_two_target/manuscript/ring_two_target_cn.pdf`, `research/reports/ring_two_target/manuscript/ring_two_target_en.pdf` | `research/reports/ring_two_target/manuscript/ring_two_target_cn.tex`, `research/reports/ring_two_target/manuscript/ring_two_target_en.tex` |
| `research/reports/ring_two_walker_encounter_shortcut` | `research/reports/ring_two_walker_encounter_shortcut/manuscript/ring_two_walker_encounter_shortcut_cn.pdf`, `research/reports/ring_two_walker_encounter_shortcut/manuscript/ring_two_walker_encounter_shortcut_en.pdf` | `research/reports/ring_two_walker_encounter_shortcut/manuscript/ring_two_walker_encounter_shortcut_cn.tex`, `research/reports/ring_two_walker_encounter_shortcut/manuscript/ring_two_walker_encounter_shortcut_en.tex` |
| `research/reports/grid2d_bimodality` | `research/reports/grid2d_bimodality/manuscript/grid2d_bimodality_cn.pdf`, `research/reports/grid2d_bimodality/manuscript/grid2d_bimodality_en.pdf` | `research/reports/grid2d_bimodality/manuscript/grid2d_bimodality_cn.tex`, `research/reports/grid2d_bimodality/manuscript/grid2d_bimodality_en.tex` |
| `research/reports/grid2d_reflecting_bimodality` | `research/reports/grid2d_reflecting_bimodality/manuscript/grid2d_reflecting_bimodality_cn.pdf`, `research/reports/grid2d_reflecting_bimodality/manuscript/grid2d_reflecting_bimodality_en.pdf` | `research/reports/grid2d_reflecting_bimodality/manuscript/grid2d_reflecting_bimodality_cn.tex`, `research/reports/grid2d_reflecting_bimodality/manuscript/grid2d_reflecting_bimodality_en.tex` |
| `research/reports/grid2d_blackboard_bimodality` | `research/reports/grid2d_blackboard_bimodality/manuscript/grid2d_blackboard_bimodality_cn.pdf`, `research/reports/grid2d_blackboard_bimodality/manuscript/grid2d_blackboard_bimodality_en.pdf` | `research/reports/grid2d_blackboard_bimodality/manuscript/grid2d_blackboard_bimodality_cn.tex`, `research/reports/grid2d_blackboard_bimodality/manuscript/grid2d_blackboard_bimodality_en.tex` |
| `research/reports/grid2d_two_target_double_peak` | `research/reports/grid2d_two_target_double_peak/manuscript/grid2d_two_target_double_peak_cn.pdf`, `research/reports/grid2d_two_target_double_peak/manuscript/grid2d_two_target_double_peak_en.pdf`, `research/reports/grid2d_two_target_double_peak/manuscript/extras/method_comparison_cn.pdf`, `research/reports/grid2d_two_target_double_peak/manuscript/extras/method_comparison_en.pdf` | `research/reports/grid2d_two_target_double_peak/manuscript/grid2d_two_target_double_peak_cn.tex`, `research/reports/grid2d_two_target_double_peak/manuscript/grid2d_two_target_double_peak_en.tex`, `research/reports/grid2d_two_target_double_peak/manuscript/extras/method_comparison_cn.tex`, `research/reports/grid2d_two_target_double_peak/manuscript/extras/method_comparison_en.tex` |
| `research/reports/grid2d_two_walker_encounter_shortcut` | `research/reports/grid2d_two_walker_encounter_shortcut/manuscript/grid2d_two_walker_encounter_shortcut_cn.pdf`, `research/reports/grid2d_two_walker_encounter_shortcut/manuscript/grid2d_two_walker_encounter_shortcut_en.pdf` | `research/reports/grid2d_two_walker_encounter_shortcut/manuscript/grid2d_two_walker_encounter_shortcut_cn.tex`, `research/reports/grid2d_two_walker_encounter_shortcut/manuscript/grid2d_two_walker_encounter_shortcut_en.tex` |
| `research/reports/grid2d_rect_bimodality` | `research/reports/grid2d_rect_bimodality/manuscript/grid2d_rect_bimodality_cn.pdf`, `research/reports/grid2d_rect_bimodality/manuscript/grid2d_rect_bimodality_en.pdf` | `research/reports/grid2d_rect_bimodality/manuscript/grid2d_rect_bimodality_cn.tex`, `research/reports/grid2d_rect_bimodality/manuscript/grid2d_rect_bimodality_en.tex` |
| `research/reports/grid2d_membrane_near_target` | `research/reports/grid2d_membrane_near_target/manuscript/grid2d_membrane_near_target_cn.pdf`, `research/reports/grid2d_membrane_near_target/manuscript/grid2d_membrane_near_target_en.pdf` | `research/reports/grid2d_membrane_near_target/manuscript/grid2d_membrane_near_target_cn.tex`, `research/reports/grid2d_membrane_near_target/manuscript/grid2d_membrane_near_target_en.tex` |
| `research/reports/grid2d_one_target_valley_peak_budget` | `research/reports/grid2d_one_target_valley_peak_budget/manuscript/grid2d_one_target_valley_peak_budget_cn.pdf`, `research/reports/grid2d_one_target_valley_peak_budget/manuscript/grid2d_one_target_valley_peak_budget_en.pdf` | `research/reports/grid2d_one_target_valley_peak_budget/manuscript/grid2d_one_target_valley_peak_budget_cn.tex`, `research/reports/grid2d_one_target_valley_peak_budget/manuscript/grid2d_one_target_valley_peak_budget_en.tex` |
| `research/reports/cross_luca_regime_map` | `research/reports/cross_luca_regime_map/manuscript/cross_luca_regime_map_cn.pdf`, `research/reports/cross_luca_regime_map/manuscript/cross_luca_regime_map_en.pdf`, `research/reports/cross_luca_regime_map/manuscript/extras/cross_luca_regime_map_cn_smoke.pdf`, `research/reports/cross_luca_regime_map/manuscript/extras/cross_luca_regime_map_en_smoke.pdf` | `research/reports/cross_luca_regime_map/manuscript/cross_luca_regime_map_cn.tex`, `research/reports/cross_luca_regime_map/manuscript/cross_luca_regime_map_en.tex`, `research/reports/cross_luca_regime_map/manuscript/extras/cross_luca_regime_map_cn_smoke.tex`, `research/reports/cross_luca_regime_map/manuscript/extras/cross_luca_regime_map_en_smoke.tex` |
| `research/reports/encounter_heterogeneous_catalytic` | `research/reports/encounter_heterogeneous_catalytic/manuscript/encounter_modality_jcp.pdf` | `research/reports/encounter_heterogeneous_catalytic/manuscript/encounter_modality_jcp.tex` |
| `research/reports/encounter_multimodal_prr` | `research/reports/encounter_multimodal_prr/manuscript/encounter_multimodal_prr.pdf` | `research/reports/encounter_multimodal_prr/manuscript/encounter_multimodal_prr_theorem_first_working.tex`, `research/reports/encounter_multimodal_prr/manuscript/encounter_multimodal_prr_supplement.tex`, `research/reports/encounter_multimodal_prr/manuscript/encounter_multimodal_prr.tex` |
| `research/reports/final_multitimescale_fpt_encounter` | `research/reports/final_multitimescale_fpt_encounter/manuscript/final_multitimescale_fpt_encounter_en.pdf` | `research/reports/final_multitimescale_fpt_encounter/manuscript/final_multitimescale_fpt_encounter_en.tex` |
| `research/reports/grid2d_one_target_base` | - | - |
| `research/reports/grid2d_one_target_exit_timing` | - | - |
| `research/reports/grid2d_one_target_window_measures` | - | - |
| `research/reports/grid2d_one_two_target_gating` | - | - |
| `research/reports/exact_recursion_method_guide` | - | - |
| `research/reports/encounter_reflecting_diagonal_decomp` | - | - |
| `research/reports/encounter_reflecting_mean_validation` | - | - |
| `research/reports/grid2d_two_target_bias_radius` | - | - |
<!-- AUTO-INDEX:END -->
