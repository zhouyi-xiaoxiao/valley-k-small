# Prescribed finite-window reaction-time modality

This archive contains the clean reader source for the main article and
Supplemental Material.  It contains no generated scientific figure or
empirical dataset; the result is analytical.

Requirements:

- REVTeX 4.2
- LaTeXmk with pdfLaTeX and BibTeX

From this directory, a deterministic rebuild is:

```bash
export SOURCE_DATE_EPOCH=1784505600
export FORCE_SOURCE_DATE=1
export LC_ALL=C
export TZ=UTC
latexmk -pdf -g -interaction=nonstopmode -halt-on-error   -file-line-error encounter_multimodal_prr_submission.tex
latexmk -pdf -g -interaction=nonstopmode -halt-on-error   -file-line-error encounter_multimodal_prr_submission_supplement.tex
```

The two PDFs should be submitted as separate article and Supplemental
Material files.  Author declarations and public-archive metadata are entered
through the journal workflow and are not inferred by this archive.
