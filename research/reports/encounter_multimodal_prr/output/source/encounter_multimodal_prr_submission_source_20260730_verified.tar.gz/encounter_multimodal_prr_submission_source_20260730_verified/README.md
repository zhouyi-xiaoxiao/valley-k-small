# Prescribed finite-window reaction-time modality

This is the append-only, verified theorem-only submission source bundle
assembled on 2026-07-30. It replaces the older 2026-07-20 archive as the
candidate upload bundle without modifying that historical archive.

The package contains the reader sources for the main article and Supplemental
Material. It contains no generated scientific figure or empirical dataset;
the result is analytical. The source identities are fixed by `SHA256SUMS`.

Requirements:

- REVTeX 4.2
- LaTeXmk with pdfLaTeX and BibTeX

From this directory, a deterministic rebuild is:

```bash
export SOURCE_DATE_EPOCH=1784505600
export FORCE_SOURCE_DATE=1
export LC_ALL=C
export TZ=UTC
latexmk -pdf -g -interaction=nonstopmode -halt-on-error \
  -file-line-error encounter_multimodal_prr_submission.tex
latexmk -pdf -g -interaction=nonstopmode -halt-on-error \
  -file-line-error encounter_multimodal_prr_submission_supplement.tex
```

The main article and Supplemental Material PDFs are separate upload objects.
Author declarations, coauthor approval, and public-archive metadata remain
author-owned journal-workflow gates and are not inferred by this archive.
