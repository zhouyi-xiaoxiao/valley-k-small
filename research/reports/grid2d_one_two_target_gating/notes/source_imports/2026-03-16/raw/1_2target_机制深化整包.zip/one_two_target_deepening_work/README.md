# one-target / two-target 机制深化 bundle

这是一份在前两轮 gating game 结果之上继续往前推进的补充包，重点不再是“如何命名 phase”，而是把机制层做实：

- one-target:
  - exact 四类分解 `L0R0 / L0R1 / L1R0 / L1R1`
  - side-aware 上/下膜拆分
  - q* 敏感性审计
- two-target:
  - `(d,dy)` 63 点 atlas
  - representative MC stage timing
  - first escape side usage
- unified:
  - one-target / two-target 统一 gate language

最关键的结果：
- one-target 的第二峰在 moderate `q*` 区间里依旧是 `L0R1` 主导。
- two-target 的第二峰在这次扫描到的参数区里是 `F_no_return` 主导，而不是 `F_rollback` 主导。
- 两者都能被写成同一个 `peak1 -> valley -> peak2` 的三窗口叙事，只是 slow branch 的物理骨架不同。

建议先看：
1. `report/one_two_target_深化报告_cn.pdf`
2. `data/one_target_representative_summary.csv`
3. `data/two_target_representative_summary.csv`
4. `data/two_target_d_dy_grid_scan.csv`
