# code/

- `build_one_two_target_deepening_bundle.py`
  - 用已有 `data/` 和 `figures/` 重建本报告 PDF，并整理 metadata / README。
- `recompute_key_mechanisms.py`
  - 最小可复现脚本。重新导入 repo 快照和 two-target gating framework，
    重算 representative 的 one-target / two-target 关键 summary。
  - 输出写到 `_recomputed/`，适合后续接回 repo pipeline 时当起点。
