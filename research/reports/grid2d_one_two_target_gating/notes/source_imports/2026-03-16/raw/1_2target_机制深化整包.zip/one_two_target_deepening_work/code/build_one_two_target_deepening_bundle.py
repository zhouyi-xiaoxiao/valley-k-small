
from __future__ import annotations

import json
import math
import os
import shutil
from pathlib import Path
from typing import Iterable, List

import pandas as pd
from PIL import Image as PILImage

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    Image,
    PageBreak,
    KeepTogether,
    HRFlowable,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "data"
FIG = BASE / "figures"
REPORT = BASE / "report"
PREV = BASE / "previous_reports"
REF = BASE / "reference_repo_snapshots"


def fmt(x, digits=3):
    if x is None:
        return "-"
    if isinstance(x, str):
        return x
    try:
        xv = float(x)
    except Exception:
        return str(x)
    if math.isnan(xv):
        return "-"
    if abs(xv) >= 100:
        return f"{xv:.0f}"
    if abs(xv) >= 10:
        return f"{xv:.1f}"
    if abs(xv) >= 1:
        return f"{xv:.{digits}f}"
    return f"{xv:.{digits}f}"


def pct(x, digits=1):
    if x is None:
        return "-"
    xv = float(x)
    if math.isnan(xv):
        return "-"
    return f"{100.0*xv:.{digits}f}%"


def image_flowable(path: Path, max_width: float, max_height: float | None = None):
    with PILImage.open(path) as im:
        w, h = im.size
    if max_height is None:
        max_height = 1000 * cm
    scale = min(max_width / w, max_height / h)
    iw = w * scale
    ih = h * scale
    return Image(str(path), width=iw, height=ih)


def make_table(rows, col_widths, styles, header_bg="#d9e8fb", body_bg="#fbfcfe", font_size=8.2):
    tbl_rows = []
    for r_idx, row in enumerate(rows):
        rr = []
        for cell in row:
            txt = str(cell)
            style = styles["TableHead"] if r_idx == 0 else styles["TableBody"]
            rr.append(Paragraph(txt, style))
        tbl_rows.append(rr)
    tbl = Table(tbl_rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor(header_bg)),
        ("TEXTCOLOR", (0,0), (-1,0), colors.HexColor("#173b63")),
        ("BACKGROUND", (0,1), (-1,-1), colors.HexColor(body_bg)),
        ("GRID", (0,0), (-1,-1), 0.35, colors.HexColor("#cfd8e3")),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING", (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
    ]))
    return tbl


def note_box(text: str, styles, width: float, bg="#eef5ff", border="#c9daf2"):
    tbl = Table([[Paragraph(text, styles["Body"])]] , colWidths=[width])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor(bg)),
        ("BOX", (0,0), (-1,-1), 0.6, colors.HexColor(border)),
        ("LEFTPADDING", (0,0), (-1,-1), 9),
        ("RIGHTPADDING", (0,0), (-1,-1), 9),
        ("TOPPADDING", (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
    ]))
    return tbl


def bullets(items: Iterable[str], styles):
    out = []
    for item in items:
        out.append(Paragraph(f"• {item}", styles["BulletCN"]))
        out.append(Spacer(1, 0.08*cm))
    return out


def on_page(canvas, doc):
    page_num = canvas.getPageNumber()
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#d8dce3"))
    canvas.setLineWidth(0.5)
    canvas.line(doc.leftMargin, A4[1]-1.25*cm, A4[0]-doc.rightMargin, A4[1]-1.25*cm)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#5b6773"))
    canvas.drawRightString(A4[0]-doc.rightMargin, 0.7*cm, f"{page_num}")
    canvas.drawString(doc.leftMargin, 0.7*cm, "one-target / two-target deepening")
    canvas.restoreState()


def build_report():
    pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="Body", fontName="STSong-Light", fontSize=10.2, leading=15.4,
        textColor=colors.HexColor("#263238"), wordWrap="CJK",
    ))
    styles.add(ParagraphStyle(
        name="BodySmall", fontName="STSong-Light", fontSize=9.0, leading=13.0,
        textColor=colors.HexColor("#263238"), wordWrap="CJK",
    ))
    styles.add(ParagraphStyle(
        name="BulletCN", fontName="STSong-Light", fontSize=10.0, leading=14.5,
        textColor=colors.HexColor("#263238"), leftIndent=0, wordWrap="CJK",
    ))
    styles.add(ParagraphStyle(
        name="TitleCN", fontName="STSong-Light", fontSize=22, leading=30,
        textColor=colors.HexColor("#133a63"), spaceAfter=6, wordWrap="CJK",
    ))
    styles.add(ParagraphStyle(
        name="SubTitleCN", fontName="STSong-Light", fontSize=12.5, leading=18,
        textColor=colors.HexColor("#4c5c68"), spaceAfter=10, wordWrap="CJK",
    ))
    styles.add(ParagraphStyle(
        name="H1CN", fontName="STSong-Light", fontSize=15.5, leading=22,
        textColor=colors.HexColor("#1d4f7a"), spaceBefore=10, spaceAfter=5, wordWrap="CJK",
    ))
    styles.add(ParagraphStyle(
        name="H2CN", fontName="STSong-Light", fontSize=12.2, leading=17,
        textColor=colors.HexColor("#1f5d8a"), spaceBefore=8, spaceAfter=4, wordWrap="CJK",
    ))
    styles.add(ParagraphStyle(
        name="CaptionCN", fontName="STSong-Light", fontSize=8.6, leading=12,
        textColor=colors.HexColor("#5b6773"), alignment=1, wordWrap="CJK", spaceBefore=2, spaceAfter=8,
    ))
    styles.add(ParagraphStyle(
        name="TableHead", fontName="STSong-Light", fontSize=8.1, leading=10.5,
        textColor=colors.HexColor("#173b63"), alignment=1, wordWrap="CJK",
    ))
    styles.add(ParagraphStyle(
        name="TableBody", fontName="STSong-Light", fontSize=7.8, leading=10.5,
        textColor=colors.HexColor("#263238"), wordWrap="CJK",
    ))

    ot_q = pd.read_csv(DATA / "one_target_qstar_sensitivity.csv")
    ot_rep = pd.read_csv(DATA / "one_target_representative_summary.csv")
    ot_side = pd.read_csv(DATA / "one_target_side_window_fractions_q05.csv")
    ot_win = pd.read_csv(DATA / "one_target_window_fractions_q05.csv")
    tt_rep = pd.read_csv(DATA / "two_target_representative_summary.csv")
    tt_grid = pd.read_csv(DATA / "two_target_d_dy_grid_scan.csv")
    tt_prog = pd.read_csv(DATA / "two_target_progress_stage_medians.csv")
    tt_side = pd.read_csv(DATA / "two_target_far_side_usage.csv")

    phase_counts = {int(k): int(v) for k, v in tt_grid["phase"].value_counts().sort_index().items()}
    phase_ge1 = tt_grid[tt_grid["phase"] >= 1]
    late_range = (float(phase_ge1["windowL_F_no_return"].min()), float(phase_ge1["windowL_F_no_return"].max()))
    late_mean = float(phase_ge1["windowL_F_no_return"].mean())
    all_late_no_return = int((phase_ge1["late_family"] == "F_no_return").sum())
    peak2_sub = ot_q[(ot_q["window"] == "peak2") & (ot_q["q_star"] <= 0.6)]
    stable_late = int((peak2_sub["dominant"] == "L0R1").sum())
    stable_total = int(len(peak2_sub))

    summary_json = {
        "one_target": {
            "peak2_l0r1_stable_count_qstar_le_0p6": stable_late,
            "peak2_total_count_qstar_le_0p6": stable_total,
            "recommended_qstar_band": [0.4, 0.6],
        },
        "two_target": {
            "grid_points": int(len(tt_grid)),
            "phase_counts": phase_counts,
            "phase_ge_1_points": int(len(phase_ge1)),
            "late_family_all_phase_ge_1": "F_no_return",
            "late_f_no_return_range": [late_range[0], late_range[1]],
            "late_f_no_return_mean": late_mean,
            "sep_gate_coarse_range": [float(phase_ge1["sep_gate_coarse"].min()), float(phase_ge1["sep_gate_coarse"].max())],
        },
    }
    with open(BASE / "analysis_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary_json, f, ensure_ascii=False, indent=2)

    pdf_path = REPORT / "one_two_target_深化报告_cn.pdf"
    doc = SimpleDocTemplate(
        str(pdf_path), pagesize=A4, leftMargin=1.6*cm, rightMargin=1.6*cm,
        topMargin=1.8*cm, bottomMargin=1.2*cm
    )
    W = doc.width
    story: List = []

    # Cover
    title_box = Table([[Paragraph("1-target 与 2-target 机制深化报告", styles["TitleCN"])],
                       [Paragraph("在前两轮 gating game bundle 基础上，再往前推进的“已做完”部分：用真实 exact / MC 结果把 one-target membrane 与 two-target no-corridor 的慢支机制钉住，并整理成可继续往论文写的叙事骨架。", styles["SubTitleCN"])]],
                      colWidths=[W])
    title_box.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#eef5ff")),
        ("BOX", (0,0), (-1,-1), 0.9, colors.HexColor("#c9daf2")),
        ("LEFTPADDING", (0,0), (-1,-1), 12),
        ("RIGHTPADDING", (0,0), (-1,-1), 12),
        ("TOPPADDING", (0,0), (-1,-1), 14),
        ("BOTTOMPADDING", (0,0), (-1,-1), 14),
    ]))
    story.append(title_box)
    story.append(Spacer(1, 0.35*cm))
    story.append(note_box(
        "一句话总览：one-target 的第二峰仍然是 L0R1 / recross-dominant；two-target 的第二峰在这次扫到的参数区里几乎完全是 F_no_return 主导。也就是说，两者都能讲成“同一个三窗口故事”，但慢支的物理骨架不一样。",
        styles, W
    ))
    story.append(Spacer(1, 0.28*cm))

    done_rows = [
        ["模块", "这次新增做到的东西", "最关键的结论"],
        ["1-target", "exact side-aware 上/下膜拆分；q* 敏感性审计；主导切换时间统计", "在 q*=0.3-0.6 的 8 个代表点上，peak2 主类全部还是 L0R1；对称膜 top/bottom leak 近乎对半，非对称膜只走 top。"],
        ["2-target", "(d,dy) 63 点 atlas；representative MC stage timing；first escape side usage", f"在 63 点里有 {phase_counts.get(2,0)} 个 phase-2、{phase_counts.get(1,0)} 个 phase-1、{phase_counts.get(0,0)} 个 phase-0；所有 {int(len(phase_ge1))} 个 phase>=1 点的晚窗主类全是 F_no_return。"],
        ["统一叙事", "把 one-target / two-target 放到同一 gate language 下", "两者都可分为 peak1 / valley / peak2 三窗口；差别不在有没有双峰，而在晚峰由哪一种 slow family 主导。"],
    ]
    story.append(make_table(done_rows, [2.4*cm, 7.4*cm, 7.2*cm], styles))
    story.append(Spacer(1, 0.3*cm))
    story.extend(bullets([
        "这份报告优先讲“已经额外做出来了什么”，不是只列下一步想法。",
        "原始数据、图、代码、参考快照都一起打包，方便你继续沿着 repo 里的 report 流程往前接。",
        "英文 family 名称保留代码里的写法，避免后续实现时名词再翻译一遍。"
    ], styles))
    story.append(PageBreak())

    # Section 1 methodology and additions
    story.append(Paragraph("1. 这次相对前两轮 bundle 具体又往前做了什么", styles["H1CN"]))
    story.append(Paragraph(
        "这次的原则是：不再只停留在“门应该怎么设”的层面，而是把 gate family 真的拿去做 exact decomposition / Monte Carlo audit。这样才能把哪些结论是稳的、哪些只是视觉上像双峰，分开讲清楚。",
        styles["Body"]
    ))
    story.append(Spacer(1, 0.1*cm))
    story.extend(bullets([
        "one-target：在 repo 一致的 membrane case 上，先做 L0R0 / L0R1 / L1R0 / L1R1 精确分解，再把 leak 细分成 top-first / bottom-first。",
        "one-target：做 q* 扫描，不直接假设 q*=0.5 就是唯一对的门，而是检查结论对门的位置有多敏感。",
        "two-target：在之前 representative 之外，补了一张 (d,dy) 63 点的机制 atlas，直接看晚峰家族是否稳定。",
        "two-target：对 representative 点额外做 MC stage timing，检查 rollback 到底慢在什么阶段；再做 first-escape side usage，看它主要从 near target 的哪一侧过去。",
        "最后把两个模型统一成同一套三窗口叙事，用来支撑你后面写论文时的主线。"
    ], styles))
    story.append(Spacer(1, 0.12*cm))
    story.append(note_box(
        "建议把这轮新增内容理解成“机制层补完”：之前的 bundle 已经把 gate language 搭起来了；这轮是在 one-target 和 two-target 上分别补了 sensitivity、side、atlas、validation 这四个缺口。",
        styles, W, bg="#f9fbfd", border="#d8e0e7"
    ))
    story.append(PageBreak())

    # Section 2 one-target
    story.append(Paragraph("2. one-target membrane：还可以继续做什么，以及这次已经额外做出来什么", styles["H1CN"]))
    story.append(Paragraph(
        "这次我把 one-target 再往前推进了三步：第一步是 exact 四类分解；第二步是把 leak 再拆成 top-first / bottom-first；第三步是做 q* 敏感性，避免机制叙事完全绑死在单个阈值上。",
        styles["Body"]
    ))
    story.append(Spacer(1, 0.1*cm))

    # one-target summary table
    ot_peak2 = ot_win[ot_win["window"] == "peak2"].copy()
    rep_map = {r["case"]: r for _, r in ot_rep.iterrows()}
    peak2_map = {r["case"]: r for _, r in ot_peak2.iterrows()}
    ot_rows = [["case", "phase", "t_peak1", "t_valley", "t_peak2", "valley/max", "sep", "peak2 的 L0R1", "L0R1 超过 L0R0 的时刻"]]
    for case in ["sym", "asym"]:
        rr = rep_map[case]
        pr = peak2_map[case]
        ot_rows.append([
            case,
            str(int(rr["phase"])),
            str(int(rr["t_peak1"])),
            str(int(rr["t_valley"])),
            str(int(rr["t_peak2"])),
            fmt(rr["valley_over_max"], 3),
            fmt(rr["sep_peaks"], 2),
            pct(pr["L0R1"], 1),
            str(int(rr["t_L0R1_gt_L0R0"])),
        ])
    story.append(make_table(ot_rows, [1.8*cm, 1.2*cm, 1.8*cm, 1.9*cm, 1.8*cm, 1.9*cm, 1.5*cm, 2.4*cm, 3.0*cm], styles))
    story.append(Spacer(1, 0.15*cm))
    story.extend(bullets([
        "代表对称膜与非对称膜两例里，peak1 都仍然是 direct 类；valley 才开始出现 leak-only 与 recross-only 的竞争；peak2 明显转成 L0R1 主导。",
        f"把 q* 从 0.3 扫到 0.6 时，peak2 的 dominant family 在 {stable_total}/{stable_total} 个代表点上都保持 L0R1；只有把 q* 推到 0.7 才发生翻转，所以更合理的工作带宽是 q*=0.4-0.6。",
        "这说明 late peak 不是因为你刚好挑了某一个 q* 才被看出来，而是 moderate gate placement 下都存在的慢支。"
    ], styles))

    fig1 = image_flowable(FIG / "one_target_peak2_qstar_sensitivity.png", W, max_height=8.4*cm)
    cap1 = Paragraph("图 1. one-target 的 peak2 对 q* 的敏感性。两个代表 case 在 q*=0.3-0.6 都保持 L0R1 占优；到 q*=0.7 才明显退化。", styles["CaptionCN"])
    story.append(KeepTogether([fig1, cap1]))
    story.append(Spacer(1, 0.1*cm))

    side_peak2 = ot_side[ot_side["window"] == "peak2"].copy()
    sym_side = side_peak2[side_peak2["case"] == "sym"].iloc[0]
    asym_side = side_peak2[side_peak2["case"] == "asym"].iloc[0]
    story.append(note_box(
        "side-aware 结果也很干净：对称膜的 peak2 里，top-first 与 bottom-first leak 近乎对半；非对称膜的 peak2 则完全没有 bottom 分支。这个结果和几何直觉一致，也说明现在的 gating game 已经能把“膜上/膜下”的物理差异真正变成可统计的量。",
        styles, W
    ))
    fig2 = image_flowable(FIG / "one_target_side_window_bars.png", W, max_height=8.6*cm)
    cap2 = Paragraph(
        f"图 2. one-target 的 side-aware 窗口组成。对称膜 peak2: top={pct(sym_side['T0']+sym_side['T1'],1)}, bottom={pct(sym_side['B0']+sym_side['B1'],1)}；非对称膜 peak2: top={pct(asym_side['T0']+asym_side['T1'],1)}, bottom={pct(asym_side['B0']+asym_side['B1'],1)}。",
        styles["CaptionCN"]
    )
    story.append(KeepTogether([fig2, cap2]))
    story.append(Spacer(1, 0.12*cm))
    story.append(Paragraph("对 one-target 来说，这轮最值得保留到论文主文里的句子", styles["H2CN"]))
    story.extend(bullets([
        "双峰不是“leak 一多就有”，而是 direct fast branch 与 recross slow branch 在时间上分开之后，valley 中间再夹着 leak-only 的传递区。",
        "膜上/膜下的 side gate 不是装饰，它们在非对称膜里直接把 bottom 分支打掉；这给了一个很干净的物理对照。",
        "q* 最适合被当成 mechanism probe，而不是唯一真相：只要放在 moderate band 内，晚峰机制结论很稳。"
    ], styles))
    story.append(PageBreak())

    # Section 3 two-target
    story.append(Paragraph("3. two-target no-corridor：这次把哪些缺口补上了", styles["H1CN"]))
    story.append(Paragraph(
        "two-target 这一块，我这次没有停在 representative case，而是补了一个真正的机制 atlas。核心问题不是“它有没有双峰”，而是“第二峰到底是 rollback 主导，还是 no-return 主导；这个结论在参数面上稳不稳”。",
        styles["Body"]
    ))
    story.append(Spacer(1, 0.12*cm))

    tt_rows = [["case", "phase", "Pnear", "Pfar", "t_peak1", "t_peak2", "peak2 的 F_no_return", "peak2 的 F_rollback", "F_no_return > N_direct", "MC 最大质量误差"]]
    for _, r in tt_rep.iterrows():
        tt_rows.append([
            r["case"],
            str(int(r["phase"])),
            pct(r["p_near"], 1),
            pct(r["p_far"], 1),
            str(int(r["t_peak1"])),
            str(int(r["t_peak2"])),
            pct(r["peak2_F_no_return"], 1),
            pct(r["peak2_F_rollback"], 1),
            str(int(r["F_no_return_gt_N_direct"])),
            fmt(r["mc_max_abs_err"], 4),
        ])
    story.append(make_table(tt_rows, [2.7*cm, 1.1*cm, 1.5*cm, 1.5*cm, 1.5*cm, 1.6*cm, 2.5*cm, 2.3*cm, 2.4*cm, 2.0*cm], styles))
    story.append(Spacer(1, 0.15*cm))
    story.extend(bullets([
        "三个 representative 点的晚窗里，F_no_return 都在约 87.5%-88.7% 这个窄区间，F_rollback 只占校正量级。",
        "这直接说明 two-target 的第二峰主干不是 rollback；rollback 确实存在，但更像是晚支上的拖慢修正，而不是晚峰骨架本身。",
        "near_mass_loss 的本质也更像是 near 这边的 fast branch 先塌，而不是 far 那边的慢支突然冒出来。"
    ], styles))

    fig3 = image_flowable(FIG / "two_target_dx_dy_phase_purity.png", W, max_height=9.5*cm)
    cap3 = Paragraph(
        f"图 3. (d,dy) 63 点机制 atlas。phase-2 有 {phase_counts.get(2,0)} 个、phase-1 有 {phase_counts.get(1,0)} 个、phase-0 有 {phase_counts.get(0,0)} 个。所有 {int(len(phase_ge1))} 个 phase>=1 点的 late family 都是 F_no_return，且晚窗 F_no_return 占比落在 {pct(late_range[0],1)} 到 {pct(late_range[1],1)}，均值 {pct(late_mean,1)}。",
        styles["CaptionCN"]
    )
    story.append(KeepTogether([fig3, cap3]))
    story.append(Spacer(1, 0.1*cm))

    fig4 = image_flowable(FIG / "two_target_progress_medians.png", W, max_height=8.4*cm)
    cap4 = Paragraph(
        "图 4. representative 两例里的 far-family stage timing。F_clean 与 F_linger 的 stage 时间几乎重合；F_rollback 在 progress1/progress2/hit 阶段系统性更晚，说明 rollback 主要负责“拖慢”而不是“搭建第二峰主支”。",
        styles["CaptionCN"]
    )
    story.append(KeepTogether([fig4, cap4]))

    fig5 = image_flowable(FIG / "two_target_first_escape_side_usage.png", W, max_height=8.2*cm)
    cap5 = Paragraph(
        "图 5. first escape side usage。代表点里 far-family 多数都偏向从 near target 的 lower side 先逃出去，这给了你 sketch 里“上/下 gate”一个真实可统计的物理对应物。",
        styles["CaptionCN"]
    )
    story.append(KeepTogether([fig5, cap5]))
    story.append(Spacer(1, 0.12*cm))

    story.append(note_box(
        "最值得直接写进主文的一句：在这次扫到的 two-target 区域里，第二峰是一个 F_no_return slow branch，不是 rollback branch。rollback 会让到达 far 的时间再拖长一截，但它不是晚峰的主体质量来源。",
        styles, W
    ))
    story.append(PageBreak())

    # Unified section
    story.append(Paragraph("4. 统一机制语言：为什么 one-target 与 two-target 可以放到同一叙事里", styles["H1CN"]))
    story.append(Paragraph(
        "把两个模型放在一起看，最有价值的不是“都能双峰”这句废话，而是：它们都能被拆成同样的三窗口故事。真正不同的是，peak2 这个 slow branch 到底是谁。",
        styles["Body"]
    ))
    fig6 = image_flowable(FIG / "unified_mechanism_ladder.png", W, max_height=8.8*cm)
    cap6 = Paragraph("图 6. 统一 gate language：同样是 peak1 -> valley -> peak2 的三窗口结构，但 one-target 的慢支是 recross，two-target 的慢支是 no-return far branch。", styles["CaptionCN"])
    story.append(KeepTogether([fig6, cap6]))
    cmp_rows = [
        ["维度", "one-target membrane", "two-target no-corridor"],
        ["peak1", "L0R0 / direct", "N_direct"],
        ["valley", "L0R0 + L1R0 + L0R1 混合", "N_detour + F_no_return 混合"],
        ["peak2", "L0R1 / recross-dominant", "F_no_return-dominant"],
        ["慢支的本质", "进过 q* 后又退回来，再晚到 target", "绕过 near 之后不回头，继续推进到 far"],
        ["side gate 的作用", "区分 top / bottom 膜通行", "区分从 near 的 upper / lower / center 哪侧逃出"],
    ]
    story.append(make_table(cmp_rows, [2.4*cm, 6.8*cm, 6.8*cm], styles))
    story.append(Spacer(1, 0.12*cm))
    story.extend(bullets([
        "因此，后面写论文时完全可以把 one-target 与 two-target 放在同一个 section 里讲：先讲 gate language，再讲两个模型分别是哪一种 slow branch。",
        "这比单独列一堆 phase figure 更有机制味，因为你不是在描述“图长什么样”，而是在描述“哪一族路径把哪一段时间支撑起来了”。",
        "而且这个 unified story 还天然支持你导师说的方向：phase 定义尽量只保留能服务机制区分的规则，不要再让一堆形状指标过度筛掉真实双峰。"
    ], styles))

    story.append(Paragraph("5. 还可以继续做哪些事：我建议的发表级路线", styles["H1CN"]))
    roadmap_rows = [
        ["优先级", "建议继续做的工作", "为什么值得先做"],
        ["1", "把 one-target / two-target 的 family decomposition 接回 repo 的 report pipeline", "这样以后扫描图、摘要表、phase atlas 都能自动带 family composition，不用在外部脚本里手工补。"],
        ["2", "把 two-target atlas 从 (d,dy) 扩到 (bx,d,dy)，并保留 late family purity", "这一步最接近可以直接写结果图；能回答“机制稳定区到底多大”。"],
        ["3", "做 family-conditioned occupancy / environment heatmap", "把“这类轨迹在哪些区域待得久”可视化，能更直接解释 valley 与 late peak。"],
        ["4", "做 reduced gate-network / semi-Markov 近似", "如果能把 full model 压到少数 gate state，还能解释 mode / half-width / separation 的来源，论文的理论味会明显更强。"],
        ["5", "重新收敛 phase 规则，只保留 peak detection + family separation 两条硬判据", "这一步会让 phase 更服务机制，而不是服务图形外观。"],
    ]
    story.append(make_table(roadmap_rows, [1.2*cm, 6.4*cm, 8.2*cm], styles))
    story.append(Spacer(1, 0.15*cm))
    story.append(note_box(
        "如果只选一件最应该马上接进 repo 的事，我会选：把 family decomposition 接进现有 report 流水线。因为一旦这件事进去了，后面的 atlas、heatmap、phase v2 基本都会自然跟上。",
        styles, W, bg="#fff9ec", border="#e8d5a4"
    ))

    # Appendix
    story.append(Paragraph("附：打包内容", styles["H2CN"]))
    manifest_rows = [
        ["目录", "内容"],
        ["report/", "本报告 PDF；如需要可继续从 code/ 里的脚本重建。"],
        ["data/", "one-target q* sensitivity、window fractions；two-target atlas、MC events、side usage 等 CSV。"],
        ["figures/", "本报告引用的 6 张图。"],
        ["reference_repo_snapshots/", "这次对齐时用到的 repo 代码快照，以及 two_target_gating_framework.py。"],
        ["previous_reports/", "前两轮已经交付过的 one-target / two-target PDF，方便串起来看。"],
        ["analysis_summary.json", "这次报告里最关键数值的机器可读摘要。"],
    ]
    story.append(make_table(manifest_rows, [3.2*cm, 12.8*cm], styles))
    story.append(Spacer(1, 0.15*cm))
    story.append(Paragraph(
        "复现说明：这次 bundle 里的数值不是手写进表格的，而是从 CSV 汇总过来的；代表点的 family 质量同时经过 MC 质量误差检查。若你后面要把它真正接进 repo，最自然的入口仍然是现有 research/reports 这条链，把 family 结果一并写进 report rows。",
        styles["BodySmall"]
    ))

    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
    return pdf_path


def write_readme():
    readme = """# one-target / two-target 机制深化 bundle

这是一份在前两轮 gating game 结果之上继续往前推进的补充包，重点不再是“如何命名 phase”，而是把机制层做实：

- one-target:
  - exact 四类分解 `L0R0 / L0R1 / L1R0 / L1R1`
  - side-aware 上/下膜拆分
  - q* 敏感性审计
- two-target:
  - `(d,dy)` 63 点 atlas
  - representative MC stage timing
  - first escape side usage
- unified:
  - one-target / two-target 统一 gate language

最关键的结果：
- one-target 的第二峰在 moderate `q*` 区间里依旧是 `L0R1` 主导。
- two-target 的第二峰在这次扫描到的参数区里是 `F_no_return` 主导，而不是 `F_rollback` 主导。
- 两者都能被写成同一个 `peak1 -> valley -> peak2` 的三窗口叙事，只是 slow branch 的物理骨架不同。

建议先看：
1. `report/one_two_target_深化报告_cn.pdf`
2. `data/one_target_representative_summary.csv`
3. `data/two_target_representative_summary.csv`
4. `data/two_target_d_dy_grid_scan.csv`
"""
    (BASE / "README.md").write_text(readme, encoding="utf-8")


def copy_reference_files():
    snapshots = {
        Path("/mnt/data/repo_membrane_report.py"): REF / "grid2d_membrane_near_target_report_snapshot.py",
        Path("/mnt/data/repo_cli.py"): REF / "packages_vkcore_grid2d_rect_bimodality_cli_snapshot.py",
        Path("/mnt/data/unzipped_two/two_target_bundle/code/two_target_gating_framework.py"): REF / "two_target_gating_framework.py",
    }
    for src, dst in snapshots.items():
        if src.exists():
            shutil.copy(src, dst)
    prev = {
        Path("/mnt/data/gating_game_deliverable/二维半透膜_gating_game备忘录.pdf"): PREV / "二维半透膜_gating_game备忘录.pdf",
        Path("/mnt/data/two_target_gating_bundle_work/report/two_target_gating_framework_cn.pdf"): PREV / "two_target_gating_framework_cn.pdf",
    }
    for src, dst in prev.items():
        if src.exists():
            shutil.copy(src, dst)


def write_metadata(pdf_path: Path):
    meta = {
        "bundle": "one_two_target_deepening_work",
        "report": pdf_path.name,
        "data_files": sorted([p.name for p in DATA.glob("*.csv")]),
        "figure_files": sorted([p.name for p in FIG.glob("*.png")]),
        "reference_snapshots": sorted([p.name for p in REF.glob("*")]),
        "previous_reports": sorted([p.name for p in PREV.glob("*.pdf")]),
    }
    (BASE / "bundle_metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")


def main():
    copy_reference_files()
    write_readme()
    pdf_path = build_report()
    write_metadata(pdf_path)
    print(pdf_path)


if __name__ == "__main__":
    main()
