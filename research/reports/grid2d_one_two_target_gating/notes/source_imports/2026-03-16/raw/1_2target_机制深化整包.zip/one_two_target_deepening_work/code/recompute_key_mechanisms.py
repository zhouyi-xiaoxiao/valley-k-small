
from __future__ import annotations

"""
Minimal reproduction script for the key mechanism summaries used in the
one-target / two-target deepening bundle.

What this script does
---------------------
1. Imports the snapshot of the current one-target membrane report logic.
2. Imports the current two-target gating framework snapshot.
3. Recomputes the representative one-target and two-target summaries.
4. Demonstrates the two main lifted analyses:
   - one-target: exact four-class + side-aware six-class decomposition
   - two-target: exact family decomposition on representative cases

It is intentionally narrower than the full bundle builder: the full scan CSVs and
figures are already shipped in data/ and figures/. This script is the shortest
starting point if you want to connect the mechanism logic back into the repo.
"""

import importlib.util
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd


BASE = Path(__file__).resolve().parents[1]
REF = BASE / "reference_repo_snapshots"
OUT = BASE / "_recomputed"


def load_snapshot_modules():
    tmp = Path(tempfile.mkdtemp(prefix="repo_snap_"))
    pkg = tmp / "src" / "vkcore" / "grid2d" / "rect_bimodality"
    pkg.mkdir(parents=True, exist_ok=True)
    for p in [tmp / "src" / "vkcore" / "__init__.py",
              tmp / "src" / "vkcore" / "grid2d" / "__init__.py",
              tmp / "src" / "vkcore" / "grid2d" / "rect_bimodality" / "__init__.py"]:
        p.write_text("", encoding="utf-8")
    shutil.copy(REF / "packages_vkcore_grid2d_rect_bimodality_cli_snapshot.py", pkg / "cli.py")

    report_dir = tmp / "research" / "reports" / "grid2d_membrane_near_target" / "code"
    report_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy(REF / "grid2d_membrane_near_target_report_snapshot.py",
                report_dir / "membrane_near_target_report.py")

    if str(tmp / "src") not in sys.path:
        sys.path.insert(0, str(tmp / "src"))

    spec = importlib.util.spec_from_file_location(
        "repo_membrane_report",
        str(report_dir / "membrane_near_target_report.py"),
    )
    repo_mem = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name] = repo_mem
    spec.loader.exec_module(repo_mem)

    spec2 = importlib.util.spec_from_file_location(
        "two_target_gating_framework",
        str(REF / "two_target_gating_framework.py"),
    )
    ttmod = importlib.util.module_from_spec(spec2)
    assert spec2 and spec2.loader
    sys.modules[spec2.name] = ttmod
    spec2.loader.exec_module(ttmod)
    return repo_mem, ttmod, tmp


def idx(x: int, y: int, Lx: int) -> int:
    return int(y) * int(Lx) + int(x)


def edge_idx_key(i: int, j: int) -> tuple[int, int]:
    return (int(i), int(j)) if int(i) <= int(j) else (int(j), int(i))


def build_one_target_reps(repo_mem):
    kwargs = dict(
        Lx=60,
        Wy=16,
        bx=-0.08,
        corridor_halfwidth=2,
        wall_margin=5,
        delta_core=1.0,
        delta_open=0.55,
        start_x=7,
        target_x=58,
    )
    rep_sym = repo_mem.build_membrane_case(**kwargs, kappa_top=0.002, kappa_bottom=0.002)
    rep_asym = repo_mem.build_membrane_case(**kwargs, kappa_top=0.002, kappa_bottom=0.0)
    return {"sym": rep_sym, "asym": rep_asym}


def one_target_exact_classes(repo_mem, case: dict, q_star: float = 0.5):
    Lx = int(case["Wy"] * 0 + 60)  # representative build uses Lx=60
    n_states = int(case["src_idx"].max()) + 1
    # infer Lx robustly from target/start x positions
    Lx = max(case["start"][0], case["target"][0]) + 2
    Wy = int(n_states // Lx)
    y_mid = int(case["wall_span"][0])

    set_A = repo_mem.build_start_basin_mask(Lx=Lx, Wy=Wy, start_x=case["start"][0], y_mid=y_mid)
    set_B = np.zeros(n_states, dtype=bool)
    set_B[idx(case["target"][0], case["target"][1], Lx)] = True
    q_values = repo_mem.solve_committor(
        n_states=n_states,
        src_idx=case["src_idx"],
        dst_idx=case["dst_idx"],
        probs=case["probs"],
        set_A=set_A,
        set_B=set_B,
    )
    membrane_idx_edges = {
        edge_idx_key(idx(a[0], a[1], Lx), idx(b[0], b[1], Lx))
        for (a, b) in case["membrane_edges"]
    }
    f_class, surv = repo_mem.exact_lr_class_fpt(
        n_states=n_states,
        start_idx=idx(case["start"][0], case["start"][1], Lx),
        src_idx=case["src_idx"],
        dst_idx=case["dst_idx"],
        probs=case["probs"],
        target_idx=idx(case["target"][0], case["target"][1], Lx),
        set_A=set_A,
        q_values=q_values,
        q_star=q_star,
        membrane_idx_edges=membrane_idx_edges,
        t_max=len(case["f_total"]) - 1,
        surv_tol=1e-12,
    )
    windows = repo_mem.window_ranges(case["res"].t_peak1, case["res"].t_valley, case["res"].t_peak2, len(case["f_total"]))
    props = repo_mem.window_fractions_from_fclass(f_class=f_class, windows=windows)
    return {
        "q_values": q_values,
        "f_class": f_class,
        "surv": surv,
        "windows": windows,
        "window_props": props,
        "set_A": set_A,
        "Lx": Lx,
        "Wy": Wy,
    }


def one_target_side_exact(repo_mem, case: dict, q_star: float = 0.5):
    base = one_target_exact_classes(repo_mem, case, q_star=q_star)
    Lx = base["Lx"]
    Wy = base["Wy"]
    n_states = int(Lx * Wy)
    q_values = base["q_values"]
    set_A = base["set_A"]
    target_idx = idx(case["target"][0], case["target"][1], Lx)
    y_mid, y_low, y_high, _, _ = case["wall_span"]

    top_edges = set()
    bottom_edges = set()
    for edge in case["membrane_edges"]:
        (x0, y0), (x1, y1) = edge
        key = edge_idx_key(idx(x0, y0, Lx), idx(x1, y1, Lx))
        lowy, highy = min(y0, y1), max(y0, y1)
        if lowy == y_high and highy == y_high + 1:
            top_edges.add(key)
        elif lowy == y_low - 1 and highy == y_low:
            bottom_edges.add(key)

    src = case["src_idx"].astype(np.int64, copy=False)
    dst = case["dst_idx"].astype(np.int64, copy=False)
    pr = case["probs"].astype(np.float64, copy=False)

    is_hit = dst == int(target_idx)
    edge_keys = np.fromiter((edge_idx_key(int(a), int(b)) for a, b in zip(src, dst)), dtype=object, count=src.size)
    is_top = np.fromiter((k in top_edges for k in edge_keys), dtype=bool, count=src.size)
    is_bottom = np.fromiter((k in bottom_edges for k in edge_keys), dtype=bool, count=src.size)
    is_A_dst = set_A[dst]
    is_sigma_dst = q_values[dst] >= float(q_star)

    src_non = src[~is_hit]
    dst_non = dst[~is_hit]
    pr_non = pr[~is_hit]
    top_non = is_top[~is_hit]
    bottom_non = is_bottom[~is_hit]
    A_non = is_A_dst[~is_hit]
    sigma_non = is_sigma_dst[~is_hit]

    src_hit = src[is_hit]
    pr_hit = pr[is_hit]
    top_hit = is_top[is_hit]
    bottom_hit = is_bottom[is_hit]

    n_flags = 12
    n_ext = n_states * n_flags
    ext_src_parts = []
    ext_dst_parts = []
    ext_pr_parts = []
    hit_src_parts = []
    hit_cls_parts = []
    hit_pr_parts = []

    def class_id(leak_state: int, recross: int) -> int:
        if leak_state == 0 and recross == 0:
            return 0  # D0
        if leak_state == 0 and recross == 1:
            return 1  # D1
        if leak_state == 1 and recross == 0:
            return 2  # T0
        if leak_state == 1 and recross == 1:
            return 3  # T1
        if leak_state == 2 and recross == 0:
            return 4  # B0
        return 5  # B1

    for leak_state in range(3):
        for s in range(2):
            for r in range(2):
                flag = leak_state + 3 * s + 6 * r
                base_flag = int(flag * n_states)

                l2_non = np.full(src_non.shape, leak_state, dtype=np.int64)
                upd_mask = l2_non == 0
                l2_non = np.where(upd_mask & top_non, 1, l2_non)
                l2_non = np.where((l2_non == 0) & bottom_non, 2, l2_non)
                s2_non = np.logical_or(bool(s), sigma_non)
                r2_non = np.logical_or(bool(r), np.logical_and(bool(s), A_non))
                flag2_non = l2_non + 3 * s2_non.astype(np.int64) + 6 * r2_non.astype(np.int64)

                ext_src_parts.append(base_flag + src_non)
                ext_dst_parts.append(dst_non + flag2_non * n_states)
                ext_pr_parts.append(pr_non)

                l2_hit = np.full(src_hit.shape, leak_state, dtype=np.int64)
                l2_hit = np.where((l2_hit == 0) & top_hit, 1, l2_hit)
                l2_hit = np.where((l2_hit == 0) & bottom_hit, 2, l2_hit)
                cls_hit = np.asarray([class_id(int(v), int(r)) for v in l2_hit], dtype=np.int64)
                hit_src_parts.append(base_flag + src_hit)
                hit_cls_parts.append(cls_hit)
                hit_pr_parts.append(pr_hit)

    ext_src = np.concatenate(ext_src_parts)
    ext_dst = np.concatenate(ext_dst_parts)
    ext_pr = np.concatenate(ext_pr_parts)
    hit_src_ext = np.concatenate(hit_src_parts)
    hit_cls = np.concatenate(hit_cls_parts)
    hit_pr = np.concatenate(hit_pr_parts)

    p = np.zeros(n_ext, dtype=np.float64)
    p[idx(case["start"][0], case["start"][1], Lx)] = 1.0

    f_class = np.zeros((len(case["f_total"]), 6), dtype=np.float64)
    surv = np.zeros(len(case["f_total"]), dtype=np.float64)
    surv[0] = 1.0
    for t in range(1, len(case["f_total"])):
        h = p[hit_src_ext] * hit_pr
        for cls in range(6):
            mask = hit_cls == cls
            if np.any(mask):
                f_class[t, cls] = float(np.sum(h[mask]))
        p_next = np.zeros_like(p)
        np.add.at(p_next, ext_dst, p[ext_src] * ext_pr)
        surv[t] = float(p_next.sum())
        p = p_next
        if surv[t] < 1e-12:
            surv[t+1:] = surv[t]
            break

    cats = ["D0", "D1", "T0", "T1", "B0", "B1"]
    out: Dict[str, Dict[str, float]] = {}
    for name, lo, hi in base["windows"]:
        mass = f_class[lo:hi+1].sum(axis=0)
        tot = float(mass.sum())
        out[name] = {c: (float(mass[i]/tot) if tot > 0 else 0.0) for i, c in enumerate(cats)}
    return {
        **base,
        "f_class_side": f_class,
        "surv_side": surv,
        "window_props_side": out,
    }


def dominant_switch_from_fclass(f_class: np.ndarray):
    names = ["L0R0", "L0R1", "L1R0", "L1R1"]
    dom = np.argmax(f_class, axis=1)
    init_dom = int(dom[1]) if f_class.shape[0] > 1 else 0
    t_change = None
    t_l0r1_gt_l0r0 = None
    for t in range(1, f_class.shape[0]):
        if t_change is None and int(dom[t]) != init_dom:
            t_change = t
        if t_l0r1_gt_l0r0 is None and float(f_class[t,1]) > float(f_class[t,0]):
            t_l0r1_gt_l0r0 = t
    return {
        "t_dom_change": t_change,
        "t_L0R1_gt_L0R0": t_l0r1_gt_l0r0,
        "init_dom": names[init_dom],
    }


def build_two_target_reps(ttmod):
    gate = ttmod.GateConfig(near_ring_radius=2, x_in_offset=0, x_out_offset=2, progress_fracs=(0.33, 0.66))
    cases = {
        "anchor": ttmod.build_case(name="anchor", near_dx=2, near_dy=2, bx=0.12),
        "clear_instance": ttmod.build_case(name="clear_instance", near_dx=4, near_dy=1, bx=0.12),
        "near_mass_loss": ttmod.build_case(name="near_mass_loss", near_dx=2, near_dy=6, bx=0.12),
    }
    return gate, cases


def first_crossing(a: np.ndarray, b: np.ndarray):
    mask = a > b
    idxs = np.nonzero(mask)[0]
    return int(idxs[0]) if len(idxs) else None


def switch_stats_two(fam):
    fc = fam.family_flux_coarse
    return {
        "F_no_return_gt_N_direct": first_crossing(fc[:,2], fc[:,0]),
        "far_total_gt_near_total": first_crossing(fc[:,2] + fc[:,3], fc[:,0] + fc[:,1]),
        "rollback_gt_detour": first_crossing(fc[:,3], fc[:,1]),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    repo_mem, ttmod, tmp = load_snapshot_modules()

    # one-target representatives
    reps = build_one_target_reps(repo_mem)
    one_rows = []
    one_q_rows = []
    for case_name, case in reps.items():
        base = one_target_exact_classes(repo_mem, case, q_star=0.5)
        side = one_target_side_exact(repo_mem, case, q_star=0.5)
        switches = dominant_switch_from_fclass(base["f_class"])
        win_peak2 = base["window_props"]["peak2"]
        side_peak2 = side["window_props_side"]["peak2"]
        one_rows.append({
            "case": case_name,
            "phase": int(case["res"].phase),
            "t_peak1": int(case["res"].t_peak1),
            "t_valley": int(case["res"].t_valley),
            "t_peak2": int(case["res"].t_peak2),
            "valley_over_max": float(case["res"].valley_over_max),
            "sep_peaks": float(case["res"].sep_peaks),
            "peak2_L0R1": float(win_peak2["L0R1"]),
            "peak2_top_total": float(side_peak2["T0"] + side_peak2["T1"]),
            "peak2_bottom_total": float(side_peak2["B0"] + side_peak2["B1"]),
            **switches,
        })
        for q_star in [0.3, 0.4, 0.5, 0.6, 0.7]:
            out = one_target_exact_classes(repo_mem, case, q_star=q_star)
            for wname, props in out["window_props"].items():
                one_q_rows.append({
                    "case": case_name, "q_star": q_star, "window": wname,
                    **props,
                    "dominant": max(props, key=props.get),
                })

    pd.DataFrame(one_rows).to_csv(OUT / "one_target_representative_summary_recomputed.csv", index=False)
    pd.DataFrame(one_q_rows).to_csv(OUT / "one_target_qstar_recomputed.csv", index=False)

    gate, cases = build_two_target_reps(ttmod)
    two_rows = []
    for cname, case in cases.items():
        fam = ttmod.run_family_exact(case, gate)
        stats = switch_stats_two(fam)
        two_rows.append({
            "case": cname,
            "phase": int(case.phase),
            "p_near": float(case.p_near),
            "p_far": float(case.p_far),
            "t_peak1": int(case.t_peak1),
            "t_peak2": int(case.t_peak2),
            "peak2_F_no_return": float(fam.peak_window_frac_coarse["peak2"][2]),
            "peak2_F_rollback": float(fam.peak_window_frac_coarse["peak2"][3]),
            "sep_gate_coarse": float(fam.sep_gate_coarse),
            **stats,
        })
    pd.DataFrame(two_rows).to_csv(OUT / "two_target_representative_summary_recomputed.csv", index=False)

    print("recomputed summaries written to", OUT)


if __name__ == "__main__":
    main()
