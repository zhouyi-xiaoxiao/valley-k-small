# Gating Game 打包说明

这个压缩包包含我整理的一版“二维半透膜 gating game + phase v2”工作备忘录，目标是：

1. 把 one-target membrane 情况做成和 1D ring shortcut 类似、可直观看懂的四类轨迹；
2. 给出更机制化的 phase 定义（只保留两条硬规则）；
3. 给出 two-target 的自然 extension；
4. 给出你下一步在 repo 里最容易落地的实现顺序。

## 文件说明

- `二维半透膜_gating_game备忘录.pdf`：主备忘录（建议先看）
- `二维半透膜_gating_game备忘录.tex`：LaTeX 源文件
- `figures/`：文中的示意图
- `code_skeleton/gating_game_skeleton.py`：建议的最小代码骨架
- `notes/phase_v2_definition.md`：phase v2 的公式化说明

## 建议阅读顺序

1. 主备忘录第 1–4 节：先把 gate 和四分类想清楚
2. 第 6–8 节：看 phase v2 和 two-target extension
3. 第 9–10 节：直接照着做下一步落地
