from dataclasses import dataclass
from typing import Iterable

@dataclass
class GateWord:
    used_excursion: bool
    used_rollback: bool
    side: str      # "none", "U", "D", "UD"
    bin_tag: str   # "none", "preQ", "postQ", "both"
    n_rollbacks: int

def collapse_repeated_events(events: list[str]) -> list[str]:
    out: list[str] = []
    for e in events:
        if not out or out[-1] != e:
            out.append(e)
    return out

def reduce_gate_word(events: list[str]) -> GateWord:
    e = collapse_repeated_events(events)
    used_excursion = any(tag in e for tag in ("U1", "D1", "U2", "D2"))
    used_rollback = False
    n_rollbacks = 0

    # rollback: after hitting Gq, return to A
    seen_gq = False
    for tag in e:
        if tag == "Gq":
            seen_gq = True
        if seen_gq and tag == "A":
            used_rollback = True
            n_rollbacks += 1
            seen_gq = False

    upper = any(tag in e for tag in ("U1", "U2"))
    lower = any(tag in e for tag in ("D1", "D2"))
    if upper and lower:
        side = "UD"
    elif upper:
        side = "U"
    elif lower:
        side = "D"
    else:
        side = "none"

    pre = any(tag in e for tag in ("U1", "D1"))
    post = any(tag in e for tag in ("U2", "D2"))
    if pre and post:
        bin_tag = "both"
    elif pre:
        bin_tag = "preQ"
    elif post:
        bin_tag = "postQ"
    else:
        bin_tag = "none"

    return GateWord(
        used_excursion=used_excursion,
        used_rollback=used_rollback,
        side=side,
        bin_tag=bin_tag,
        n_rollbacks=n_rollbacks,
    )

def top_level_class(word: GateWord) -> str:
    return f"C{int(word.used_excursion)}{int(word.used_rollback)}"

def mode_time(f):
    import numpy as np
    if len(f) <= 1:
        return 0
    return int(np.argmax(f[1:]) + 1)

def half_width(f, t_mode: int) -> float:
    if t_mode <= 0 or t_mode >= len(f):
        return 0.0
    peak = float(f[t_mode])
    if peak <= 0:
        return 0.0
    thr = 0.5 * peak
    left = t_mode
    right = t_mode
    while left > 1 and f[left - 1] >= thr:
        left -= 1
    while right < len(f) - 1 and f[right + 1] >= thr:
        right += 1
    return 0.5 * (right - left)

def gate_sep(f_fast, f_slow) -> float:
    tf = mode_time(f_fast)
    ts = mode_time(f_slow)
    wf = half_width(f_fast, tf)
    ws = half_width(f_slow, ts)
    return abs(ts - tf) / max(wf + ws, 1e-12)

def classify_phase_one_target_v2(t_peak1, t_peak2, f_fast, f_slow) -> int:
    has_double = int(t_peak1 is not None and t_peak2 is not None)
    sep = gate_sep(f_fast, f_slow)
    return 2 if (has_double and sep >= 1.0) else (1 if has_double else 0)
