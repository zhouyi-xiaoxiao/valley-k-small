# phase v2（建议稿）

## One-target membrane

- Rule 1：`find_two_peaks` 仍然检测到两个可信峰；
- Rule 2：存在一对主导 gate family，它们的条件 FPT 在时间上分开：

\[
sep_{gate} = |t_mode(slow)-t_mode(fast)| / (hw_fast + hw_slow) >= 1.
\]

推荐第一版：
- `fast = C00`
- `slow = C10 + C01 + C11`

如果代表案例确认 second peak 更纯粹来自 rollback family，则改成：
- `fast = C00`
- `slow = C01 + C11`

## Two-target

- Rule 1：总 FPT 有两个可信峰；
- Rule 2：near / far 两支 branch 的模态时间分开：

\[
sep_{branch} = |t_mode(far)-t_mode(near)| / (hw_near + hw_far) >= 1.
\]

## 旧指标怎么处理

这些量不要删，但从 hard phase gate 移出去，只作为 diagnostics：

- `valley/max`
- `peak_balance`
- `peak_ratio`
- `min(Pnear, Pfar)`
- `peak_margin`
- `gate_slack`
