Corrected calculation manuscript
================================

Main file:
  Calculations_corrected_sendable.tex

Precompiled PDF:
  Calculations_corrected_sendable.pdf

Compile command:
  latexmk -pdf -interaction=nonstopmode -halt-on-error Calculations_corrected_sendable.tex

Included local dependencies:
  customcommands.sty
  customcolours.sty
  globalplotconfig.sty
  phifunction.pdf
  Calculations_corrected_sendableNotes.bib

The displayed correction is in the shortcut section. In particular, the
rank-one sign is propagated through the corrected Eq. (32), Eq. (33), the
antipodal shortcut expression, the final closed form for the first-passage
generating function, and the explicit long-time dependence governed by the
dominant root of the corrected denominator.

The appendix now records the full direct time-convolution route, including the
Eq. (41)-style long expansion, and then shows how that route recombines to the
same compact closed form. In particular, Appendix A.4 writes Eq. (57) both in
compact kernel notation and in a fully expanded partial-fraction form, including
the diagonal limits that visibly produce t alpha-type intermediate terms. After
the full expression is collected, the apparent alpha poles are removable and the
final poles are the roots of the corrected denominator. Appendix A.5 explicitly
z-transforms the Eq. (57) groups back to the generating-function route, making
the recombination step visible. Appendix B writes the apparent alpha denominator
explicitly as a removable T_L factor. Appendix C includes the numerical-validation
protocol, the summary errors, and the sampled beta bounds for the N=100, q=2/3,
n0=1,...,6 finite-time double-peak check. The local audit folder contains the
script and CSV/JSON outputs used for those checks.
